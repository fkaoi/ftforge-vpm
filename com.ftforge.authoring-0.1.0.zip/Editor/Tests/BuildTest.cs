using System.Linq;
using System.Text;
using FTForge.Bridge;
using FTForge.Core;
using UnityEngine;

namespace FTForge.Tests
{
    static class BuildTest
    {
        /// <summary>
        /// Build check: runs the full NDMF pipeline (MA, AAO, FTForge...) on a copy of the variant prefab and verifies
        /// the result the way VRChat would get it.
        /// </summary>
        [BridgeCommand("testBuild")]
        static string Build(string variantPath)
        {
            var prefab = UnityEditor.AssetDatabase.LoadAssetAtPath<GameObject>(variantPath) ?? throw new System.ArgumentException(variantPath);
            var scene = UnityEditor.SceneManagement.EditorSceneManager.NewPreviewScene();
            var sb = new StringBuilder();
            try
            {
                var clone = (GameObject)UnityEditor.PrefabUtility.InstantiatePrefab(prefab, scene);
                UnityEditor.PrefabUtility.UnpackPrefabInstance(clone, UnityEditor.PrefabUnpackMode.Completely, UnityEditor.InteractionMode.AutomatedAction);
                var data = clone.GetComponentInChildren<FTForgeApply>().data;
                nadena.dev.ndmf.AvatarProcessor.ProcessAvatar(clone);

                var d = clone.GetComponent<VRC.SDK3.Avatars.Components.VRCAvatarDescriptor>();
                var state = Adapters.VrcFaceTrackingAdapter.Read(d);
                var unresolved = Adapters.VrcFaceTrackingAdapter.UnresolvedBlendshapes(d);
                void Check(string what, bool ok) => sb.AppendLine($"{(ok ? "PASS" : "FAIL")} {what}");
                Check("FTForge Apply removed", clone.GetComponentInChildren<FTForgeApply>(true) == null);
                Check($"face tracking enabled ({state.enabled}), lipSync={state.lipSync}, gaze={state.eyeGazeMode}, eyelid={state.eyelidType}", state.enabled && state.lipSync == "VisemeBlendShapeFaceTracking");
                Check($"mapped keys {state.mappedKeys} (data has {data.mappings.Count})", state.mappedKeys == data.mappings.Count);
                Check($"SDK validator: {unresolved.Count} unresolved", unresolved.Count == 0);
                foreach (var md in data.meshes)
                {
                    var t = clone.transform.Find(md.rendererPath);
                    var r = t != null ? t.GetComponent<SkinnedMeshRenderer>() : null;
                    int present = r == null ? 0 : md.shapes.Count(x => r.sharedMesh.GetBlendShapeIndex(x.name) >= 0);
                    Check($"{md.rendererPath}: {present}/{md.shapes.Count} generated blendshapes survive the build (mesh '{(r != null ? r.sharedMesh.name : "missing")}')", present == md.shapes.Count);
                }
                int? ops = null;
                try { ops = Adapters.VrcFaceTrackingAdapter.MeasureOperations(clone); } catch { }
                sb.AppendLine($"FT operations after build: {ops?.ToString() ?? "n/a"}; FT meshes: {string.Join(", ", state.meshes)}");

                // the source assets are untouched
                var srcFace = UnityEditor.AssetDatabase.LoadAssetAtPath<GameObject>(Pipeline.DefaultPrefab).GetComponentsInChildren<SkinnedMeshRenderer>(true).First(x => x.name == "Body").sharedMesh;
                Check($"source mesh unchanged ({srcFace.blendShapeCount} blendshapes, no FTForge names)", data.meshes.SelectMany(m => m.shapes).All(x => srcFace.GetBlendShapeIndex(x.name) < 0));
            }
            finally { UnityEditor.SceneManagement.EditorSceneManager.ClosePreviewScene(scene); }
            return sb.ToString();
        }

        /// <summary>Buyer's view: original avatar + exported drop-in prefab → build. Also: mismatched data is refused.</summary>
        [BridgeCommand("testPackage")]
        static string Package(string args)
        {
            var parts = args.Split('|');
            var avatar = UnityEditor.AssetDatabase.LoadAssetAtPath<GameObject>(parts[0]);
            var apply = UnityEditor.AssetDatabase.LoadAssetAtPath<GameObject>(parts[1]);
            var scene = UnityEditor.SceneManagement.EditorSceneManager.NewPreviewScene();
            var sb = new StringBuilder();
            void Check(string what, bool ok) => sb.AppendLine($"{(ok ? "PASS" : "FAIL")} {what}");
            try
            {
                var root = (GameObject)UnityEditor.PrefabUtility.InstantiatePrefab(avatar, scene);
                var a = (GameObject)UnityEditor.PrefabUtility.InstantiatePrefab(apply, scene);
                a.transform.SetParent(root.transform, false);
                UnityEditor.PrefabUtility.UnpackPrefabInstance(root, UnityEditor.PrefabUnpackMode.Completely, UnityEditor.InteractionMode.AutomatedAction);
                UnityEditor.PrefabUtility.UnpackPrefabInstance(a, UnityEditor.PrefabUnpackMode.Completely, UnityEditor.InteractionMode.AutomatedAction);
                var data = root.GetComponentInChildren<FTForgeApply>().data;
                nadena.dev.ndmf.AvatarProcessor.ProcessAvatar(root);
                var d = root.GetComponent<VRC.SDK3.Avatars.Components.VRCAvatarDescriptor>();
                var state = Adapters.VrcFaceTrackingAdapter.Read(d);
                Check($"drop-in prefab applied: {state.mappedKeys} keys mapped, FT enabled={state.enabled}", state.enabled && state.mappedKeys == data.mappings.Count);
                Check($"SDK validator after build: {Adapters.VrcFaceTrackingAdapter.UnresolvedBlendshapes(d).Count} unresolved", Adapters.VrcFaceTrackingAdapter.UnresolvedBlendshapes(d).Count == 0);

                // mismatch: same data with a wrong base hash must be refused, leaving the mesh alone
                var root2 = (GameObject)UnityEditor.PrefabUtility.InstantiatePrefab(avatar, scene);
                var bad = Object.Instantiate(data);
                bad.meshes[0].baseHash = "0000";
                var body = root2.transform.Find(bad.meshes[0].rendererPath).GetComponent<SkinnedMeshRenderer>();
                var before = body.sharedMesh;
                var log = ShapeApply.Apply(root2.transform, bad, false);
                Check($"mismatched mesh refused: \"{log.FirstOrDefault()}\"", log.Any(l => l.StartsWith("ERROR")) && body.sharedMesh == before);
                Object.DestroyImmediate(bad);
            }
            finally { UnityEditor.SceneManagement.EditorSceneManager.ClosePreviewScene(scene); }
            return sb.ToString();
        }
    }
}
