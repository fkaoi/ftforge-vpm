using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Adds generated blendshapes to a copy of a mesh. The source mesh and FBX are never modified.
    /// (Phase 3 moves this into an NDMF pass at build time; the copy here is for preview and testing.)
    /// </summary>
    public static class MeshWriter
    {
        public static Mesh CreateWithShapes(Mesh source, IEnumerable<GeneratedShape> shapes)
        {
            var mesh = UnityEngine.Object.Instantiate(source);
            mesh.name = source.name + "_FTForge";
            foreach (var shape in shapes)
            {
                if (shape.delta.Length != mesh.vertexCount)
                    throw new ArgumentException($"{shape.name}: {shape.delta.Length} deltas for {mesh.vertexCount} vertices");
                if (mesh.GetBlendShapeIndex(shape.name) >= 0)
                    throw new ArgumentException($"{mesh.name} already has a blendshape named {shape.name}");
                mesh.AddBlendShapeFrame(shape.name, 100f, shape.delta, NormalDelta(source, shape.delta), null);
            }
            return mesh;
        }

        /// <summary>
        /// Normal change caused by a position delta: recalculated normals of the deformed mesh minus those of the base.
        /// Unmoved regions cancel out exactly, so only the deformed area gets non-zero values.
        /// </summary>
        /// Normals are accumulated on the welded surface: Unity duplicates vertices along UV seams, and
        /// recalculating each copy separately gives the two sides of a seam different normals (dark shading blotches).
        public static Vector3[] NormalDelta(Mesh source, Vector3[] delta)
        {
            var basePos = source.vertices;
            var tris = source.triangles;
            var weld = new Topology(source).Weld;
            int groups = weld.Max() + 1;

            Vector3[] Welded(Vector3[] pos)
            {
                var acc = new Vector3[groups];
                for (int t = 0; t < tris.Length; t += 3)
                {
                    int a = tris[t], b = tris[t + 1], c = tris[t + 2];
                    var n = Vector3.Cross(pos[b] - pos[a], pos[c] - pos[a]); // area-weighted
                    acc[weld[a]] += n; acc[weld[b]] += n; acc[weld[c]] += n;
                }
                for (int g = 0; g < groups; g++) acc[g] = acc[g].normalized;
                return acc;
            }

            var n0 = Welded(basePos);
            var moved = new Vector3[basePos.Length];
            for (int i = 0; i < moved.Length; i++) moved[i] = basePos[i] + delta[i];
            var n1 = Welded(moved);
            var result = new Vector3[basePos.Length];
            for (int i = 0; i < result.Length; i++) result[i] = n1[weld[i]] - n0[weld[i]];
            return result;
        }

        public static Mesh SaveAsset(Mesh mesh, string assetPath)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(assetPath));
            var existing = AssetDatabase.LoadAssetAtPath<Mesh>(assetPath);
            if (existing != null)
            {
                EditorUtility.CopySerialized(mesh, existing);
                AssetDatabase.SaveAssets();
                return existing;
            }
            AssetDatabase.CreateAsset(mesh, assetPath);
            return mesh;
        }
    }
}
