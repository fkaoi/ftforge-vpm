using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;

namespace FTForge.Core
{
    /// <summary>
    /// An avatar prefab instantiated in an isolated preview scene, so the user's open scene is never touched.
    /// </summary>
    public sealed class AvatarSession : IDisposable
    {
        public readonly Scene Scene;
        public readonly GameObject Prefab;
        public readonly GameObject Root;
        public readonly VRCAvatarDescriptor Descriptor;
        public readonly Animator Animator;

        public AvatarSession(string prefabPath)
        {
            Prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath)
                     ?? throw new ArgumentException($"Prefab not found: {prefabPath}");
            Scene = EditorSceneManager.NewPreviewScene();
            Root = (GameObject)PrefabUtility.InstantiatePrefab(Prefab, Scene);
            Root.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            Descriptor = Root.GetComponent<VRCAvatarDescriptor>()
                         ?? throw new ArgumentException($"No VRCAvatarDescriptor on {prefabPath}");
            Animator = Root.GetComponent<Animator>();
        }

        public Transform Head =>
            Animator != null && Animator.isHuman ? Animator.GetBoneTransform(HumanBodyBones.Head) : null;

        public IEnumerable<SkinnedMeshRenderer> Renderers =>
            Root.GetComponentsInChildren<SkinnedMeshRenderer>(true).Where(r => r.sharedMesh != null);

        public string PathOf(Transform t) => AnimationUtility.CalculateTransformPath(t, Root.transform);

        public SkinnedMeshRenderer FindRenderer(string path) =>
            Renderers.FirstOrDefault(r => PathOf(r.transform) == path);

        public void ResetBlendShapes()
        {
            foreach (var r in Renderers)
                for (int i = 0; i < r.sharedMesh.blendShapeCount; i++)
                    r.SetBlendShapeWeight(i, 0f);
        }

        public void Dispose()
        {
            if (Scene.IsValid()) EditorSceneManager.ClosePreviewScene(Scene);
        }
    }
}
