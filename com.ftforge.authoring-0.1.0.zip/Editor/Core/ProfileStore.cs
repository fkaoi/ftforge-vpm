using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using FTForge.Adapters;
using UnityEditor;
using UnityEngine;

namespace FTForge.Core
{
    public static class ProfileStore
    {
        public static string DefaultPath(GameObject prefab) =>
            $"{Pipeline.WorkFolder}/{Synthesizer.Sanitize(prefab.name)}/{Synthesizer.Sanitize(prefab.name)}_FTForgeProfile.asset";

        /// <summary>Finds the profile made for this prefab, or creates one with an entry per UE key.</summary>
        public static FTForgeProfile LoadOrCreate(GameObject prefab)
        {
            string path = DefaultPath(prefab);
            var profile = AssetDatabase.LoadAssetAtPath<FTForgeProfile>(path);
            if (profile == null)
            {
                foreach (var guid in AssetDatabase.FindAssets("t:FTForgeProfile"))
                {
                    var p = AssetDatabase.LoadAssetAtPath<FTForgeProfile>(AssetDatabase.GUIDToAssetPath(guid));
                    if (p != null && p.avatarPrefab == prefab) { profile = p; break; }
                }
            }
            if (profile == null)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                profile = ScriptableObject.CreateInstance<FTForgeProfile>();
                profile.avatarPrefab = prefab;
                AssetDatabase.CreateAsset(profile, path);
            }
            foreach (var key in VrcFaceTrackingAdapter.KeyNames) profile.GetOrAdd(key);
            // keep SDK key order
            var order = VrcFaceTrackingAdapter.KeyNames.Select((k, i) => (k, i)).ToDictionary(x => x.k, x => x.i);
            profile.keys = profile.keys.Where(k => order.ContainsKey(k.key)).OrderBy(k => order[k.key]).ToList();
            return profile;
        }

        /// <summary>Writes automatic results; leaves manual fields (mode, value, multiplier, falloff, approved, memo) alone.</summary>
        public static void StoreResults(FTForgeProfile profile, AnalysisReport analysis, List<KeyEvaluation> evals, string summary)
        {
            Undo.RecordObject(profile, "FTForge results");
            var byKey = evals.ToDictionary(e => e.key);
            foreach (var k in analysis.keys)
            {
                var entry = profile.GetOrAdd(k.key);
                byKey.TryGetValue(k.key, out var e);
                string newShape = k.status == nameof(KeyStatus.Unavailable) ? "" : k.shape ?? "";
                string newRecipe = k.rule ?? "";
                // A changed result needs a fresh human look.
                if (entry.approved && (entry.shape != newShape || entry.recipe != newRecipe)) entry.approved = false;
                entry.status = k.status + (k.source != null ? $" ({k.source})" : "");
                entry.shape = newShape;
                entry.recipe = newRecipe;
                entry.score = e?.score ?? 0;
                entry.issues = e != null ? string.Join("; ", e.issues) : k.note ?? "";
                entry.candidatesTried = e?.candidatesTried ?? 0;
            }
            profile.lastRun = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            profile.lastSummary = summary;
            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssetIfDirty(profile);
        }
    }
}
