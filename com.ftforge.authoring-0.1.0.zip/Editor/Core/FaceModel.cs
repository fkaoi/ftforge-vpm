using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Geometry of one mesh in avatar space plus facial landmarks and soft region masks.
    /// Avatar space: origin at the head bone, x = avatar's right, y = up, z = forward, metres.
    /// All per-vertex arrays use the Unity mesh's vertex order.
    /// </summary>
    public sealed class FaceModel
    {
        public readonly AvatarSession Session;
        public readonly SkinnedMeshRenderer Renderer;
        public readonly Mesh Mesh;
        public readonly int VertexCount;
        public readonly Vector3[] Rest;          // avatar space, all weights 0
        public readonly Matrix4x4[] Skin;        // mesh space -> world, per vertex (linear blend skinning at rest)
        public readonly int[] EdgeA, EdgeB;      // unique triangle edges

        // Landmarks (avatar space)
        public float Iod;
        public Vector3 EyeL, EyeR;
        public float MouthLineY, MouthHalfWidth;
        public float MidY;                       // between eyes and mouth line
        public string LandmarkNote = "";

        readonly Transform _root;
        readonly Vector3 _origin;

        public FaceModel(AvatarSession s, SkinnedMeshRenderer r)
        {
            Session = s;
            Renderer = r;
            Mesh = r.sharedMesh;
            VertexCount = Mesh.vertexCount;
            _root = s.Root.transform;
            _origin = s.Head != null ? s.Head.position : _root.position;

            var weights = MeshSampler.SaveWeights(r);
            for (int i = 0; i < weights.Length; i++) r.SetBlendShapeWeight(i, 0f);
            var world = MeshSampler.BakeWorld(r);
            MeshSampler.RestoreWeights(r, weights);
            Rest = world.Select(ToAvatar).ToArray();
            Skin = SkinMatrices(r);
            (EdgeA, EdgeB) = Edges(Mesh.triangles);
            FindLandmarks();
        }

        public Vector3 ToAvatar(Vector3 worldPoint) => _root.InverseTransformDirection(worldPoint - _origin);
        public Vector3 FromAvatarDir(Vector3 v) => _root.TransformDirection(v);

        /// <summary>Mesh-space blendshape delta -> avatar-space displacement.</summary>
        public Vector3[] ToAvatarDelta(Vector3[] meshDelta)
        {
            var d = new Vector3[meshDelta.Length];
            for (int i = 0; i < d.Length; i++)
                d[i] = _root.InverseTransformDirection(Skin[i].MultiplyVector(meshDelta[i]));
            return d;
        }

        public Vector3[] ShapeDelta(string name) => BlenderBridge.ShapeDelta(Mesh, name);

        static Matrix4x4[] SkinMatrices(SkinnedMeshRenderer r)
        {
            var mesh = r.sharedMesh;
            int n = mesh.vertexCount;
            var result = new Matrix4x4[n];
            var bones = r.bones;
            var bind = mesh.bindposes;
            var bw = mesh.boneWeights;
            if (bones == null || bones.Length == 0 || bw.Length != n)
            {
                for (int i = 0; i < n; i++) result[i] = r.transform.localToWorldMatrix;
                return result;
            }
            var boneMats = new Matrix4x4[bones.Length];
            for (int b = 0; b < bones.Length; b++)
                boneMats[b] = bones[b] != null ? bones[b].localToWorldMatrix * bind[b] : r.transform.localToWorldMatrix;
            for (int i = 0; i < n; i++)
            {
                var w = bw[i];
                var m = Scale(boneMats[w.boneIndex0], w.weight0);
                if (w.weight1 > 0) m = Add(m, Scale(boneMats[w.boneIndex1], w.weight1));
                if (w.weight2 > 0) m = Add(m, Scale(boneMats[w.boneIndex2], w.weight2));
                if (w.weight3 > 0) m = Add(m, Scale(boneMats[w.boneIndex3], w.weight3));
                result[i] = m;
            }
            return result;
        }

        static Matrix4x4 Scale(Matrix4x4 m, float s) { for (int i = 0; i < 16; i++) m[i] *= s; return m; }
        static Matrix4x4 Add(Matrix4x4 a, Matrix4x4 b) { for (int i = 0; i < 16; i++) a[i] += b[i]; return a; }

        static (int[], int[]) Edges(int[] tris)
        {
            var set = new HashSet<long>();
            var a = new List<int>(); var b = new List<int>();
            void Add(int x, int y)
            {
                if (x > y) (x, y) = (y, x);
                if (set.Add(((long)x << 32) | (uint)y)) { a.Add(x); b.Add(y); }
            }
            for (int t = 0; t < tris.Length; t += 3) { Add(tris[t], tris[t + 1]); Add(tris[t + 1], tris[t + 2]); Add(tris[t + 2], tris[t]); }
            return (a.ToArray(), b.ToArray());
        }

        void FindLandmarks()
        {
            var s = Session;
            var l = s.Animator != null && s.Animator.isHuman ? s.Animator.GetBoneTransform(HumanBodyBones.LeftEye) : null;
            var r = s.Animator != null && s.Animator.isHuman ? s.Animator.GetBoneTransform(HumanBodyBones.RightEye) : null;
            if (l == null || r == null) { l = s.Descriptor.customEyeLookSettings.leftEye; r = s.Descriptor.customEyeLookSettings.rightEye; }
            if (l == null || r == null) throw new Exception("Eye bones are required to locate the face.");
            EyeL = ToAvatar(l.position);
            EyeR = ToAvatar(r.position);
            Iod = Vector3.Distance(EyeL, EyeR);
            float eyeY = (EyeL.y + EyeR.y) * 0.5f;

            // Mouth from the "aa" viseme: the line is midway between upward- and downward-moving lip vertices.
            MouthLineY = eyeY - Iod;
            MouthHalfWidth = 0.35f * Iod;
            LandmarkNote = "mouth estimated from eyes";
            string aaName = s.Descriptor.VisemeBlendShapes != null && s.Descriptor.VisemeBlendShapes.Length > 10 ? s.Descriptor.VisemeBlendShapes[10] : "vrc.v_aa";
            if (Mesh.GetBlendShapeIndex(aaName) >= 0)
            {
                var d = ToAvatarDelta(ShapeDelta(aaName));
                float max = d.Max(v => v.magnitude);
                if (max > 1e-5f)
                {
                    var moved = Enumerable.Range(0, VertexCount).Where(i => d[i].magnitude > 0.2f * max).ToList();
                    float cx = moved.Average(i => Rest[i].x);
                    MouthHalfWidth = moved.Max(i => Mathf.Abs(Rest[i].x - cx));
                    var central = moved.Where(i => Mathf.Abs(Rest[i].x - cx) < MouthHalfWidth * 0.5f).ToList();
                    var up = central.Where(i => d[i].y > 0).Select(i => Rest[i].y).OrderBy(y => y).ToList();
                    var down = central.Where(i => d[i].y < 0).Select(i => Rest[i].y).OrderBy(y => y).ToList();
                    if (up.Count > 0 && down.Count > 0) MouthLineY = (up[up.Count / 2] + down[down.Count / 2]) * 0.5f;
                    else if (down.Count > 0) MouthLineY = down.Max();
                    LandmarkNote = $"mouth from viseme {aaName}";
                }
            }
            MidY = (eyeY + MouthLineY) * 0.5f;
        }

        // ---------------- stage D seeds ----------------

        Topology _topo;
        public Topology Topo => _topo ??= new Topology(Mesh);

        float[] _visible;
        /// <summary>
        /// 1 for vertices on the outer, front-facing skin (what a front camera sees), else 0.
        /// Vertex-only stand-in for "will this motion show up in the image".
        /// </summary>
        public float[] Visible => _visible ??= ComputeVisible(0.025f, 0.02f);

        float[] _visibleStrict;
        /// <summary>
        /// Stricter variant for stage D: only the very front layer counts, so parts just behind the skin
        /// (inner mouth) are made to follow the skin in front of them instead of being pushed through it.
        /// </summary>
        public float[] VisibleStrict => _visibleStrict ??= ComputeVisible(0.015f, 0.004f);

        float[] ComputeVisible(float cellIod, float depthIod)
        {
            var normals = Mesh.normals;
            float cell = cellIod * Iod, depthTol = depthIod * Iod;
            var front = new Dictionary<Vector2Int, float>();
            Vector2Int Cell(Vector3 p) => new Vector2Int(Mathf.FloorToInt(p.x / cell), Mathf.FloorToInt(p.y / cell));
            for (int i = 0; i < VertexCount; i++)
            {
                var c = Cell(Rest[i]);
                front[c] = front.TryGetValue(c, out var z) ? Mathf.Max(z, Rest[i].z) : Rest[i].z;
            }
            var v = new float[VertexCount];
            for (int i = 0; i < VertexCount; i++)
            {
                var n = normals.Length == VertexCount ? _root.InverseTransformDirection(Skin[i].MultiplyVector(normals[i])).normalized : Vector3.forward;
                if (n.z < 0.2f) continue;
                if (Rest[i].z >= front[Cell(Rest[i])] - depthTol) v[i] = 1f;
            }
            return v;
        }
        Dictionary<string, float[]> _seeds;
        public string SeedNote = "";
        /// <summary>"geodesic" when the lips are separated by a visible opening, else "euclid" (see Blender push).</summary>
        public string SeedMetric = "euclid";
        public static readonly string[] SeedNames = { "upperRim", "lowerRim", "rim", "corners" };

        /// <summary>
        /// Seed weights for stage D deformations. The lip edges are found from open boundary loops around the
        /// mouth (holes block geodesic falloff, so a push on one lip does not leak through the opening);
        /// a loop that moves up under the "aa" viseme is the upper rim, one that moves down the lower rim.
        /// Without such loops the lip region masks near the mouth line are used instead.
        /// </summary>
        public float[] Seeds(string name)
        {
            if (_seeds == null) BuildSeeds();
            if (_seeds.TryGetValue(name, out var w)) return w;
            throw new ArgumentException("Unknown seed '" + name + "'. Known: " + string.Join(", ", SeedNames));
        }

        void BuildSeeds()
        {
            _seeds = new Dictionary<string, float[]>();
            var upper = new float[VertexCount];
            var lower = new float[VertexCount];
            string aaName = Session.Descriptor.VisemeBlendShapes != null && Session.Descriptor.VisemeBlendShapes.Length > 10 ? Session.Descriptor.VisemeBlendShapes[10] : "vrc.v_aa";
            Vector3[] aa = Mesh.GetBlendShapeIndex(aaName) >= 0 ? ToAvatarDelta(ShapeDelta(aaName)) : null;
            var topo = Topo;
            var loops = topo.BoundaryLoops.Where(l => l.Count >= 8).Select(l => l.SelectMany(w => topo.Members[w]).ToList())
                .Where(vs =>
                {
                    var c = vs.Aggregate(Vector3.zero, (a, b) => a + Rest[b]) / vs.Count;
                    return Mathf.Abs(c.x) < 0.1f * Iod && Mathf.Abs(c.y - MouthLineY) < 0.4f * Iod && c.z > 0
                           && vs.Max(i => Mathf.Abs(Rest[i].x)) < MouthHalfWidth * 1.6f;
                }).ToList();
            List<int> up = null, down = null;
            float bestUp = 0, bestDown = 0;
            if (aa != null)
                foreach (var vs in loops)
                {
                    float dy = vs.Average(i => aa[i].y);
                    if (dy > bestUp) { bestUp = dy; up = vs; }
                    if (dy < bestDown) { bestDown = dy; down = vs; }
                }
            void Fill(List<int> vs, float[] w)
            {
                float half = vs.Max(i => Mathf.Abs(Rest[i].x));
                foreach (int i in vs) w[i] = 1 - Smooth(0.7f * half, half, Mathf.Abs(Rest[i].x)) * 0.7f; // softer at the corners
            }
            var vis = Visible;
            float VisibleShare(List<int> vs) => vs.Average(i => vis[i]);
            if (up != null && down != null && (VisibleShare(up) < 0.5f || VisibleShare(down) < 0.5f))
            {
                SeedNote = $"mouth loops are hidden (visible {VisibleShare(up):P0}/{VisibleShare(down):P0}, probably the inner mouth); ";
                up = down = null;
            }
            if (up != null && down != null)
            {
                Fill(up, upper);
                Fill(down, lower);
                SeedNote += "lip rims from boundary loops (" + up.Count + "/" + down.Count + " vertices)";
                SeedMetric = "geodesic";
            }
            else
            {
                // Visible skin along the mouth line, fading over a short band above / below it.
                float band = 0.06f * Iod;
                for (int i = 0; i < VertexCount; i++)
                {
                    if (vis[i] <= 0 || Mathf.Abs(Rest[i].x) > MouthHalfWidth * 1.05f) continue;
                    float dy = Rest[i].y - MouthLineY;
                    float side = 1 - Smooth(0.75f * MouthHalfWidth, 1.05f * MouthHalfWidth, Mathf.Abs(Rest[i].x)) * 0.7f;
                    if (dy >= 0 && dy < band) upper[i] = (1 - Smooth(0, band, dy)) * side;
                    if (dy <= 0 && dy > -band) lower[i] = (1 - Smooth(0, band, -dy)) * side;
                }
                SeedNote += "lip rims from the visible skin along the mouth line";
            }
            var rim = new float[VertexCount];
            var corners = new float[VertexCount];
            float halfAll = Enumerable.Range(0, VertexCount).Where(i => upper[i] > 0 || lower[i] > 0).Select(i => Mathf.Abs(Rest[i].x)).DefaultIfEmpty(MouthHalfWidth).Max();
            for (int i = 0; i < VertexCount; i++)
            {
                rim[i] = Mathf.Max(upper[i], lower[i]);
                if (rim[i] > 0) corners[i] = Smooth(0.7f * halfAll, 0.95f * halfAll, Mathf.Abs(Rest[i].x));
            }
            _seeds["upperRim"] = upper;
            _seeds["lowerRim"] = lower;
            _seeds["rim"] = rim;
            _seeds["corners"] = corners;
        }

        /// <summary>Avatar-space direction at a vertex -> mesh space (inverse of the skinning at rest).</summary>
        public Vector3 ToMeshDir(int vertex, Vector3 avatarDir) =>
            Skin[vertex].inverse.MultiplyVector(_root.TransformDirection(avatarDir));

        /// <summary>World metres per mesh unit around the given vertices.</summary>
        public float MeshScale(IEnumerable<int> vertices)
        {
            var list = vertices.ToList();
            if (list.Count == 0) return 1f;
            return list.Average(i => Skin[i].MultiplyVector(Vector3.up).magnitude);
        }

        // ---------------- regions ----------------

        public static readonly string[] RegionNames =
            { "upperLip", "lowerLip", "mouth", "jaw", "nose", "cheekL", "cheekR", "eyeL", "eyeR", "browL", "browR", "upperFace", "lowerFace" };

        static float Smooth(float edge0, float edge1, float x)
        {
            float t = Mathf.Clamp01((x - edge0) / (edge1 - edge0));
            return t * t * (3 - 2 * t);
        }

        /// <summary>1 inside the band [lo, hi], fading to 0 over <paramref name="f"/> outside it.</summary>
        static float Band(float x, float lo, float hi, float f) => Smooth(lo - f, lo, x) * (1 - Smooth(hi, hi + f, x));

        /// <summary>
        /// Soft mask (0..1) per vertex. <paramref name="falloff"/> is in IODs; default 0.08.
        /// </summary>
        public float[] RegionMask(string region, float falloff = 0.08f)
        {
            float f = Mathf.Max(1e-4f, falloff * Iod);
            float eyeY = (EyeL.y + EyeR.y) * 0.5f;
            var m = new float[VertexCount];
            for (int i = 0; i < VertexCount; i++)
            {
                var p = Rest[i];
                float ax = Mathf.Abs(p.x);
                float mouthX = 1 - Smooth(MouthHalfWidth * 1.15f, MouthHalfWidth * 1.15f + 2 * f, ax);
                m[i] = region switch
                {
                    "upperLip" => Smooth(MouthLineY - f * 0.5f, MouthLineY + f * 0.5f, p.y) * Band(p.y, MouthLineY, MouthLineY + 0.35f * Iod, f) * mouthX,
                    "lowerLip" => (1 - Smooth(MouthLineY - f * 0.5f, MouthLineY + f * 0.5f, p.y)) * Band(p.y, MouthLineY - 0.45f * Iod, MouthLineY, f) * mouthX,
                    "mouth" => Band(p.y, MouthLineY - 0.45f * Iod, MouthLineY + 0.35f * Iod, f) * mouthX,
                    "jaw" => 1 - Smooth(MouthLineY + 0.1f * Iod - f, MouthLineY + 0.1f * Iod, p.y),
                    "nose" => Band(p.y, MouthLineY + 0.25f * Iod, eyeY - 0.15f * Iod, f) * (1 - Smooth(0.2f * Iod, 0.2f * Iod + f, ax)),
                    "cheekL" => Band(p.y, MouthLineY - 0.1f * Iod, eyeY - 0.2f * Iod, f) * Smooth(MouthHalfWidth, MouthHalfWidth + f, -p.x),
                    "cheekR" => Band(p.y, MouthLineY - 0.1f * Iod, eyeY - 0.2f * Iod, f) * Smooth(MouthHalfWidth, MouthHalfWidth + f, p.x),
                    "eyeL" => 1 - Smooth(0.55f * Iod, 0.55f * Iod + f, Vector2.Distance(new Vector2(p.x, p.y), new Vector2(EyeL.x, EyeL.y))),
                    "eyeR" => 1 - Smooth(0.55f * Iod, 0.55f * Iod + f, Vector2.Distance(new Vector2(p.x, p.y), new Vector2(EyeR.x, EyeR.y))),
                    "browL" => Band(p.y, EyeL.y + 0.25f * Iod, EyeL.y + 1.1f * Iod, f) * (1 - Smooth(0.7f * Iod, 0.7f * Iod + f, Mathf.Abs(p.x - EyeL.x))),
                    "browR" => Band(p.y, EyeR.y + 0.25f * Iod, EyeR.y + 1.1f * Iod, f) * (1 - Smooth(0.7f * Iod, 0.7f * Iod + f, Mathf.Abs(p.x - EyeR.x))),
                    "upperFace" => Smooth(MidY - f, MidY + f, p.y),
                    "lowerFace" => 1 - Smooth(MidY - f, MidY + f, p.y),
                    _ => throw new ArgumentException($"Unknown region '{region}'. Known: {string.Join(", ", RegionNames)}"),
                };
            }
            return m;
        }

        /// <summary>Weight of the requested side: 1 on that side, smoothstep across the centre band (metres). L + R = 1.</summary>
        public float[] SideMask(string side, float falloffMetres)
        {
            float half = Mathf.Max(falloffMetres, 1e-6f) * 0.5f;
            var w = new float[VertexCount];
            for (int i = 0; i < VertexCount; i++)
            {
                float right = Smooth(-half, half, Rest[i].x);
                w[i] = side == "Right" ? right : 1 - right;
            }
            return w;
        }
    }
}
