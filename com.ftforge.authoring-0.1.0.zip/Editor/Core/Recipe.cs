using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Small expression language for stages B and C. Evaluates to a mesh-space delta per vertex.
    ///
    ///   expr  := term ( (" + " | " - ") term )*          binary operators need spaces around them
    ///   term  := [ "-" ] [ number "*" ] atom
    ///   atom  := shapeName | "quoted name" | func "(" args ")" | "(" expr ")"
    ///   split(expr, Left|Right [, falloff])     stage B: keep one side; falloff in metres across the centre line
    ///   mask(expr, region [, falloff])          stage C: keep only a face region; falloff in IODs (see FaceModel.RegionNames)
    ///   clampDown(expr) / clampUp(expr)         keep only downward / upward motion (avatar space)
    ///   deform(seed, dx, dy, dz, radius [, toCentre])   stage D (Blender): push the seed vertices by (dx,dy,dz) IOD in
    ///       avatar space, fading by surface distance over radius IOD; toCentre pulls them toward the middle (IOD).
    ///       Seeds: upperRim lowerRim rim corners (see FaceModel.Seeds).
    ///   jawBake(degrees)                        stage D: bake the humanoid Jaw bone opened by the given angle
    ///       (unavailable when the avatar has no Jaw bone).
    ///
    /// Shape names end at whitespace, ',', '(', ')' or '*'; quote names containing those.
    /// Parameters written as $name are filled from the profile (e.g. $falloff).
    /// References: @Key is the blendshape already mapped to that UE key (e.g. @JawOpen),
    /// @v_xx is the descriptor's viseme shape (e.g. @v_ih, @v_ou).
    /// Example: split(mask(mouth_I_1, upperLip), Left)    0.5*mouth_A_1 - 0.5*mouth_I_1
    /// </summary>
    public static class Recipe
    {
        public abstract class Node
        {
            public abstract Vector3[] Eval(Context c);
            public abstract IEnumerable<string> Shapes();
            public virtual IEnumerable<Node> Children() { yield break; }
            public IEnumerable<Node> All() => new[] { this }.Concat(Children().SelectMany(n => n.All()));
        }

        /// <summary>Stage D: bone deformation baked into a blendshape (humanoid Jaw rotated about the avatar's x axis).</summary>
        public sealed class JawBakeNode : Node
        {
            public float degrees;
            public override Vector3[] Eval(Context c)
            {
                string key = "jawBake(" + degrees.ToString(CultureInfo.InvariantCulture) + ")";
                if (c.precomputed.TryGetValue(key, out var cached)) return (Vector3[])cached.Clone();
                var f = c.face;
                var anim = f.Session.Animator;
                var jaw = anim != null && anim.isHuman ? anim.GetBoneTransform(HumanBodyBones.Jaw) : null;
                if (jaw == null) throw new InvalidOperationException("no humanoid Jaw bone");
                var r = f.Renderer;
                var weights = MeshSampler.SaveWeights(r);
                for (int i = 0; i < weights.Length; i++) r.SetBlendShapeWeight(i, 0f);
                var before = MeshSampler.BakeWorld(r);
                var rot = jaw.rotation;
                jaw.rotation = Quaternion.AngleAxis(degrees, f.Session.Root.transform.right) * rot;
                var after = MeshSampler.BakeWorld(r);
                jaw.rotation = rot;
                MeshSampler.RestoreWeights(r, weights);
                var d = new Vector3[before.Length];
                for (int i = 0; i < d.Length; i++) d[i] = f.Skin[i].inverse.MultiplyVector(after[i] - before[i]);
                c.precomputed[key] = d;
                return (Vector3[])d.Clone();
            }
            public override IEnumerable<string> Shapes() { yield break; }
        }

        /// <summary>Stage D. Results are computed in Blender beforehand and looked up by <see cref="Key"/>.</summary>
        public sealed class DeformNode : Node
        {
            public string seed;
            public float dx, dy, dz, radius, toCentre;
            public string Key => string.Format(CultureInfo.InvariantCulture, "deform({0},{1},{2},{3},{4},{5})", seed, dx, dy, dz, radius, toCentre);
            public override Vector3[] Eval(Context c)
            {
                if (c.precomputed.TryGetValue(Key, out var d)) return (Vector3[])d.Clone();
                throw new InvalidOperationException(Key + " was not computed (Blender step missing)");
            }
            public override IEnumerable<string> Shapes() { yield break; }
        }

        public sealed class Context
        {
            public FaceModel face;
            public Dictionary<string, float> parameters = new Dictionary<string, float>();
            public float defaultSplitFalloff = 0.01f;
            public float defaultMaskFalloff = 0.08f;
            /// <summary>Resolves @references to blendshape names; returns null when unresolvable.</summary>
            public Func<string, string> resolve = n => n;
            /// <summary>When true, split/mask pass motion through unchanged (reference for crease checks).</summary>
            public bool noMasks;
            /// <summary>Stage D results by DeformNode.Key (mesh-space deltas).</summary>
            public Dictionary<string, Vector3[]> precomputed = new Dictionary<string, Vector3[]>();
            readonly Dictionary<string, Vector3[]> _cache = new Dictionary<string, Vector3[]>();
            public Vector3[] Shape(string name)
            {
                string real = name.StartsWith("@") ? resolve(name) ?? throw new KeyNotFoundException($"{name} is not mapped") : name;
                return _cache.TryGetValue(real, out var d) ? d : _cache[real] = face.ShapeDelta(real);
            }
        }

        public static Node Parse(string text) => new Parser(text).ParseAll();

        /// <summary>True when every shape the recipe needs exists on the mesh.</summary>
        public static bool Available(Node n, Mesh mesh, Func<string, string> resolve) =>
            n.Shapes().All(s =>
            {
                string real = s.StartsWith("@") ? resolve(s) : s;
                return real != null && mesh.GetBlendShapeIndex(real) >= 0;
            });

        // ---------------- nodes ----------------

        sealed class ShapeNode : Node
        {
            public string name;
            public override Vector3[] Eval(Context c) => (Vector3[])c.Shape(name).Clone();
            public override IEnumerable<string> Shapes() { yield return name; }
        }

        sealed class ScaleNode : Node
        {
            public float k; public Node a;
            public override Vector3[] Eval(Context c) { var v = a.Eval(c); for (int i = 0; i < v.Length; i++) v[i] *= k; return v; }
            public override IEnumerable<string> Shapes() => a.Shapes();
            public override IEnumerable<Node> Children() { yield return a; }
        }

        sealed class SumNode : Node
        {
            public List<(float sign, Node node)> terms = new List<(float, Node)>();
            public override Vector3[] Eval(Context c)
            {
                Vector3[] acc = null;
                foreach (var (sign, node) in terms)
                {
                    var v = node.Eval(c);
                    if (acc == null) { acc = v; if (sign < 0) for (int i = 0; i < acc.Length; i++) acc[i] = -acc[i]; }
                    else for (int i = 0; i < acc.Length; i++) acc[i] += sign * v[i];
                }
                return acc;
            }
            public override IEnumerable<string> Shapes() => terms.SelectMany(t => t.node.Shapes());
            public override IEnumerable<Node> Children() => terms.Select(t => t.node);
        }

        sealed class FuncNode : Node
        {
            public string func; public Node a; public string word; public Arg number;
            public override Vector3[] Eval(Context c)
            {
                var v = a.Eval(c);
                if (c.noMasks && (func == "split" || func == "mask")) return v;
                switch (func)
                {
                    case "split":
                    {
                        if (word != "Left" && word != "Right") throw new FormatException($"split needs Left or Right, got '{word}'");
                        var w = c.face.SideMask(word, number?.Value(c) ?? c.defaultSplitFalloff);
                        for (int i = 0; i < v.Length; i++) v[i] *= w[i];
                        return v;
                    }
                    case "mask":
                    {
                        var w = c.face.RegionMask(word, number?.Value(c) ?? c.defaultMaskFalloff);
                        for (int i = 0; i < v.Length; i++) v[i] *= w[i];
                        return v;
                    }
                    case "clampDown":
                    case "clampUp":
                    {
                        // Judge direction in avatar space, but keep the mesh-space vector.
                        var av = c.face.ToAvatarDelta(v);
                        for (int i = 0; i < v.Length; i++)
                            if (func == "clampDown" ? av[i].y > 0 : av[i].y < 0) v[i] = Vector3.zero;
                        return v;
                    }
                    default: throw new FormatException($"Unknown function '{func}'");
                }
            }
            public override IEnumerable<string> Shapes() => a.Shapes();
            public override IEnumerable<Node> Children() { yield return a; }
        }

        public sealed class Arg
        {
            public float? literal; public string param;
            public float Value(Context c)
            {
                if (literal.HasValue) return literal.Value;
                if (c.parameters.TryGetValue(param, out var v)) return v;
                throw new KeyNotFoundException($"Recipe parameter ${param} is not set in the profile");
            }
        }

        // ---------------- parser ----------------

        sealed class Parser
        {
            readonly string _s; int _p;
            public Parser(string s) { _s = s.Trim(); }

            public Node ParseAll()
            {
                var n = ParseExpr();
                SkipWs();
                if (_p != _s.Length) throw Error("unexpected text");
                return n;
            }

            Exception Error(string msg) => new FormatException($"Recipe '{_s}': {msg} at {_p}");
            void SkipWs() { while (_p < _s.Length && char.IsWhiteSpace(_s[_p])) _p++; }
            // Peek: skips whitespace only when the character matches, so " + " stays visible to ParseExpr.
            bool At(char ch)
            {
                int save = _p;
                SkipWs();
                if (_p < _s.Length && _s[_p] == ch) return true;
                _p = save;
                return false;
            }
            void Expect(char ch) { if (!At(ch)) throw Error($"expected '{ch}'"); _p++; }

            Node ParseExpr()
            {
                var sum = new SumNode();
                sum.terms.Add((1f, ParseTerm()));
                while (true)
                {
                    int save = _p;
                    // binary + / - must be surrounded by whitespace so names may contain '-'
                    if (_p < _s.Length && char.IsWhiteSpace(_s[_p]))
                    {
                        SkipWs();
                        if (_p + 1 < _s.Length && (_s[_p] == '+' || _s[_p] == '-') && char.IsWhiteSpace(_s[_p + 1]))
                        {
                            float sign = _s[_p] == '+' ? 1f : -1f;
                            _p += 2;
                            sum.terms.Add((sign, ParseTerm()));
                            continue;
                        }
                    }
                    _p = save;
                    break;
                }
                return sum.terms.Count == 1 && sum.terms[0].sign > 0 ? sum.terms[0].node : sum;
            }

            Node ParseTerm()
            {
                SkipWs();
                float k = 1f;
                if (At('-')) { _p++; k = -1f; }
                SkipWs();
                int save = _p;
                if (TryNumber(out float num) && At('*')) { _p++; k *= num; }
                else _p = save;
                var atom = ParseAtom();
                return Mathf.Approximately(k, 1f) ? atom : new ScaleNode { k = k, a = atom };
            }

            bool TryNumber(out float v)
            {
                SkipWs();
                int start = _p;
                while (_p < _s.Length && (char.IsDigit(_s[_p]) || _s[_p] == '.')) _p++;
                return float.TryParse(_s.Substring(start, _p - start), NumberStyles.Float, CultureInfo.InvariantCulture, out v);
            }

            Node ParseAtom()
            {
                SkipWs();
                if (At('(')) { _p++; var e = ParseExpr(); Expect(')'); return e; }
                string name = ParseName();
                if (name == "jawBake" && At('('))
                {
                    _p++;
                    SkipWs();
                    bool neg = _p < _s.Length && _s[_p] == '-';
                    if (neg) _p++;
                    if (!TryNumber(out float deg)) throw Error("jawBake expects degrees");
                    Expect(')');
                    return new JawBakeNode { degrees = neg ? -deg : deg };
                }
                if (name == "deform" && At('('))
                {
                    _p++;
                    var d = new DeformNode { seed = ParseName() };
                    d.dx = NextNumber(); d.dy = NextNumber(); d.dz = NextNumber(); d.radius = NextNumber();
                    if (At(',')) d.toCentre = NextNumber();
                    Expect(')');
                    return d;
                }
                if (At('('))
                {
                    _p++;
                    var f = new FuncNode { func = name, a = ParseExpr() };
                    if (At(',')) { _p++; f.word = ParseName(); }
                    if (At(',')) { _p++; f.number = ParseArg(); }
                    Expect(')');
                    if ((f.func == "split" || f.func == "mask") && f.word == null) throw Error($"{f.func} needs a second argument");
                    return f;
                }
                return new ShapeNode { name = name };
            }

            float NextNumber()
            {
                Expect(',');
                SkipWs();
                bool neg = _p < _s.Length && _s[_p] == '-';
                if (neg) _p++;
                if (!TryNumber(out float v)) throw Error("deform expects numbers");
                return neg ? -v : v;
            }

            Arg ParseArg()
            {
                SkipWs();
                if (At('$')) { _p++; return new Arg { param = ParseName() }; }
                if (TryNumber(out float v)) return new Arg { literal = v };
                throw Error("expected a number or $parameter");
            }

            string ParseName()
            {
                SkipWs();
                if (_p < _s.Length && _s[_p] == '"')
                {
                    int end = _s.IndexOf('"', _p + 1);
                    if (end < 0) throw Error("unterminated quote");
                    string q = _s.Substring(_p + 1, end - _p - 1);
                    _p = end + 1;
                    return q;
                }
                var sb = new StringBuilder();
                while (_p < _s.Length && !char.IsWhiteSpace(_s[_p]) && _s[_p] != ',' && _s[_p] != '(' && _s[_p] != ')' && _s[_p] != '*')
                    sb.Append(_s[_p++]);
                if (sb.Length == 0) throw Error("expected a name");
                return sb.ToString();
            }
        }
    }
}
