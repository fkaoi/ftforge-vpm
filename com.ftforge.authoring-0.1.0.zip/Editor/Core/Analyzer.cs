using System;
using System.Collections.Generic;
using System.Linq;
using FTForge.Adapters;
using UnityEngine;

namespace FTForge.Core
{
    public enum KeyStatus { Existing, Alias, Synthesizable, Unavailable }

    [Serializable]
    public sealed class KeyResult
    {
        public string key;
        public string status;     // KeyStatus as text (JsonUtility friendly)
        public string source;     // exact | alias | manual | rule | disabled
        public string meshPath;
        public string shape;      // blendshape to map (existing or to-be-generated name)
        public string rule;       // chosen recipe when generated
        public List<string> candidates = new List<string>(); // recipes to try when Synthesizable
        public float multiplier = 1f;
        public string note;
        public float leftShare, rightShare, maxDisplacementMm;
    }

    [Serializable]
    public sealed class MeshEntry
    {
        public string path;
        public int vertexCount;
        public int blendShapeCount;
    }

    [Serializable]
    public sealed class AnalysisReport
    {
        public string avatar;
        public string faceMesh;
        public List<MeshEntry> meshes = new List<MeshEntry>();
        public List<KeyResult> keys = new List<KeyResult>();
        public int existing, alias, synthesizable, unavailable;

        public void Count()
        {
            existing = keys.Count(k => k.status == nameof(KeyStatus.Existing));
            alias = keys.Count(k => k.status == nameof(KeyStatus.Alias));
            synthesizable = keys.Count(k => k.status == nameof(KeyStatus.Synthesizable));
            unavailable = keys.Count(k => k.status == nameof(KeyStatus.Unavailable));
        }
    }

    /// <summary>
    /// For every Unified Expressions key decides: already present / present under another name /
    /// can be generated / cannot be generated. Order: manual override → exact name → alias → recipe.
    /// </summary>
    public static class Analyzer
    {
        // A one-sided candidate must put at least this share of its motion on the expected side.
        const float SideDominance = 0.8f;

        public static AnalysisReport Run(AvatarSession s, FTForgeProfile profile = null)
        {
            var report = new AnalysisReport { avatar = s.Prefab.name };
            var renderers = s.Renderers.ToList();
            foreach (var r in renderers)
                report.meshes.Add(new MeshEntry { path = s.PathOf(r.transform), vertexCount = r.sharedMesh.vertexCount, blendShapeCount = r.sharedMesh.blendShapeCount });

            var face = FindFaceMesh(s, renderers, profile);
            report.faceMesh = face != null ? s.PathOf(face.transform) : null;
            var faceModel = face != null ? new FaceModel(s, face) : null;

            var aliases = Rules.LoadAliases(profile != null ? profile.extraAliases : "");
            var recipes = Rules.LoadRecipes(profile != null ? profile.extraRecipes : "");
            s.ResetBlendShapes();

            var others = new Dictionary<SkinnedMeshRenderer, Vector3[]>();
            Vector3 origin = s.Head != null ? s.Head.position : s.Root.transform.position;
            MeshSampler.MotionStats Measure(SkinnedMeshRenderer r, int index)
            {
                if (r == face)
                {
                    var d = faceModel.ToAvatarDelta(faceModel.ShapeDelta(r.sharedMesh.GetBlendShapeName(index)));
                    return Summarise(faceModel, d);
                }
                if (!others.TryGetValue(r, out var b)) others[r] = b = MeshSampler.BakeWorld(r);
                return MeshSampler.Summarise(b, MeshSampler.WorldDelta(r, index), s.Root.transform, origin);
            }

            // ---- pass 1: overrides, exact names, aliases ----
            var pending = new List<KeyResult>();
            foreach (string key in VrcFaceTrackingAdapter.KeyNames)
            {
                var res = new KeyResult { key = key };
                report.keys.Add(res);
                var ov = profile?.Get(key);
                if (ov != null) res.multiplier = ov.multiplier;
                string side = Rules.SideOf(key);

                if (ov != null && ov.mode == FTForgeProfile.OverrideMode.Disable)
                {
                    res.status = nameof(KeyStatus.Unavailable); res.source = "disabled"; res.note = "disabled in profile";
                    continue;
                }
                if (ov != null && ov.mode == FTForgeProfile.OverrideMode.UseShape)
                {
                    var hit = FindShape(renderers, ov.value, StringComparison.Ordinal, face);
                    if (hit.renderer == null) { res.status = nameof(KeyStatus.Unavailable); res.source = "manual"; res.note = $"override shape '{ov.value}' not found"; continue; }
                    Fill(res, KeyStatus.Alias, s, hit.renderer, ov.value, Measure(hit.renderer, hit.index));
                    res.source = "manual";
                    continue;
                }
                if (ov != null && ov.mode == FTForgeProfile.OverrideMode.UseRecipe)
                {
                    res.status = nameof(KeyStatus.Synthesizable); res.source = "manual";
                    res.meshPath = report.faceMesh; res.shape = key; res.candidates.Add(ov.value);
                    continue;
                }

                var exact = FindShape(renderers, key, StringComparison.Ordinal);
                if (exact.renderer != null)
                {
                    Fill(res, KeyStatus.Existing, s, exact.renderer, key, Measure(exact.renderer, exact.index));
                    res.source = "exact";
                    continue;
                }

                var candidates = (aliases.TryGetValue(key, out var a) ? a : new List<string>())
                    .Concat(VrcFaceTrackingAdapter.SdkAliases(key)).Distinct().ToList();
                var rejected = new List<string>();
                bool found = false;
                foreach (string cand in candidates)
                {
                    var hit = FindShape(renderers, cand, StringComparison.OrdinalIgnoreCase, face);
                    if (hit.renderer == null) continue;
                    var stats = Measure(hit.renderer, hit.index);
                    if (stats.movedVertices == 0) { rejected.Add($"{cand}: no motion"); continue; }
                    if (side != null)
                    {
                        float share = side == "Left" ? stats.leftShare : stats.rightShare;
                        if (share < SideDominance) { rejected.Add($"{cand}: only {share:P0} on {side}"); continue; }
                    }
                    Fill(res, KeyStatus.Alias, s, hit.renderer, hit.renderer.sharedMesh.GetBlendShapeName(hit.index), stats);
                    res.source = "alias";
                    found = true;
                    break;
                }
                if (rejected.Count > 0) res.note = "rejected: " + string.Join("; ", rejected);
                if (!found) pending.Add(res);
            }

            // ---- pass 2: recipes (on the face mesh), resolving @references against pass 1 ----
            var resolve = Resolver(s, report, face);
            foreach (var res in pending)
            {
                if (faceModel != null && recipes.TryGetValue(res.key, out var list))
                {
                    var usable = list.Where(r => Recipe.Available(Recipe.Parse(r), face.sharedMesh, resolve)).ToList();
                    if (usable.Count > 0)
                    {
                        res.status = nameof(KeyStatus.Synthesizable); res.source = "rule";
                        res.meshPath = report.faceMesh; res.shape = res.key; res.candidates = usable;
                        continue;
                    }
                }
                res.status = nameof(KeyStatus.Unavailable);
                res.source ??= "none";
                res.note = (res.note != null ? res.note + " | " : "") + "no alias or recipe";
            }

            s.ResetBlendShapes();
            report.Count();
            return report;
        }

        /// <summary>@Key → shape mapped in this report on the face mesh; @v_xx → descriptor viseme.</summary>
        public static Func<string, string> Resolver(AvatarSession s, AnalysisReport report, SkinnedMeshRenderer face)
        {
            var visemes = VrcFaceTrackingAdapter.ReadVisemes(s.Descriptor);
            var visemeNames = VrcFaceTrackingAdapter.VisemeNames;
            string facePath = face != null ? s.PathOf(face.transform) : null;
            return name =>
            {
                if (!name.StartsWith("@")) return name;
                string n = name.Substring(1);
                if (n.StartsWith("v_"))
                {
                    for (int i = 0; i < visemeNames.Count && i < visemes.Length; i++)
                        if (string.Equals(visemeNames[i], n.Substring(2), StringComparison.OrdinalIgnoreCase))
                            return string.IsNullOrEmpty(visemes[i]) ? null : visemes[i];
                    return null;
                }
                var k = report.keys.FirstOrDefault(x => x.key == n);
                bool mapped = k != null && (k.status == nameof(KeyStatus.Existing) || k.status == nameof(KeyStatus.Alias)) && k.meshPath == facePath;
                return mapped ? k.shape : null;
            };
        }

        public static MeshSampler.MotionStats Summarise(FaceModel f, Vector3[] avatarDelta)
        {
            var st = new MeshSampler.MotionStats();
            float total = 0, left = 0, right = 0; Vector3 c = Vector3.zero;
            float dead = 0.03f * f.Iod;
            for (int i = 0; i < avatarDelta.Length; i++)
            {
                float d = avatarDelta[i].magnitude;
                if (d < 1e-5f) continue;
                st.movedVertices++;
                st.maxDisplacement = Mathf.Max(st.maxDisplacement, d);
                total += d; c += f.Rest[i] * d;
                if (f.Rest[i].x > dead) right += d; else if (f.Rest[i].x < -dead) left += d;
            }
            if (total > 0) { st.leftShare = left / total; st.rightShare = right / total; st.centroid = c / total; }
            return st;
        }

        static void Fill(KeyResult res, KeyStatus status, AvatarSession s, SkinnedMeshRenderer r, string shape, MeshSampler.MotionStats st)
        {
            res.status = status.ToString();
            res.meshPath = s.PathOf(r.transform);
            res.shape = shape;
            res.leftShare = st.leftShare;
            res.rightShare = st.rightShare;
            res.maxDisplacementMm = st.maxDisplacement * 1000f;
        }

        /// <summary>Profile path, else the viseme mesh, else the mesh with the most blendshapes.</summary>
        public static SkinnedMeshRenderer FindFaceMesh(AvatarSession s, List<SkinnedMeshRenderer> renderers, FTForgeProfile profile = null)
        {
            if (profile != null && !string.IsNullOrEmpty(profile.faceMeshPath))
            {
                var r = s.FindRenderer(profile.faceMeshPath);
                if (r != null) return r;
            }
            var viseme = s.Descriptor.VisemeSkinnedMesh;
            if (viseme != null && viseme.sharedMesh != null) return viseme;
            return renderers.OrderByDescending(r => r.sharedMesh.blendShapeCount).FirstOrDefault();
        }

        static (SkinnedMeshRenderer renderer, int index) FindShape(List<SkinnedMeshRenderer> renderers, string name, StringComparison cmp, SkinnedMeshRenderer prefer = null)
        {
            IEnumerable<SkinnedMeshRenderer> order = prefer != null ? new[] { prefer }.Concat(renderers.Where(r => r != prefer)) : renderers;
            foreach (var r in order)
            {
                var m = r.sharedMesh;
                for (int i = 0; i < m.blendShapeCount; i++)
                    if (string.Equals(m.GetBlendShapeName(i), name, cmp)) return (r, i);
            }
            return (null, -1);
        }
    }
}
