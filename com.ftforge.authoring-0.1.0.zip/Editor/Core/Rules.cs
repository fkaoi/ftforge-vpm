using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FTForge.Core
{
    /// <summary>Loads the text rule files in Data/ plus the per-avatar extras stored in the profile.</summary>
    public static class Rules
    {
        public const string PackageRoot = "Packages/com.ftforge.authoring";
        public const string AliasFile = PackageRoot + "/Data/aliases.txt";
        public const string RecipeFile = PackageRoot + "/Data/synth_rules.txt";

        /// <summary>key -> candidate blendshape names in priority order. Profile extras come first.</summary>
        public static Dictionary<string, List<string>> LoadAliases(string extra = "")
        {
            var result = new Dictionary<string, List<string>>(StringComparer.Ordinal);
            foreach (var (key, value) in ReadEntries(extra ?? "", "profile").Concat(ReadEntries(File.ReadAllText(AliasFile), AliasFile)))
            {
                if (!result.TryGetValue(key, out var list)) result[key] = list = new List<string>();
                list.AddRange(value.Split('|').Select(s => s.Trim()).Where(s => s.Length > 0));
            }
            return result;
        }

        /// <summary>key -> candidate recipes in priority order. Profile extras come first. Each line is one candidate.</summary>
        public static Dictionary<string, List<string>> LoadRecipes(string extra = "")
        {
            var result = new Dictionary<string, List<string>>(StringComparer.Ordinal);
            foreach (var (key, value) in ReadEntries(extra ?? "", "profile").Concat(ReadEntries(File.ReadAllText(RecipeFile), RecipeFile)))
            {
                Recipe.Parse(value); // fail early on syntax errors, naming the file
                if (!result.TryGetValue(key, out var list)) result[key] = list = new List<string>();
                if (!list.Contains(value)) list.Add(value);
            }
            return result;
        }

        static IEnumerable<(string key, string value)> ReadEntries(string text, string source)
        {
            foreach (var raw in text.Split('\n'))
            {
                var line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;
                int colon = line.IndexOf(':');
                if (colon <= 0) throw new FormatException($"{source}: missing ':' in '{line}'");
                yield return (line.Substring(0, colon).Trim(), line.Substring(colon + 1).Trim());
            }
        }

        // Keys whose Left/Right is a direction of motion, not the half of the face that moves.
        static readonly HashSet<string> DirectionalKeys = new HashSet<string>
        {
            "JawLeft", "JawRight", "MouthUpperLeft", "MouthUpperRight", "MouthLowerLeft", "MouthLowerRight",
            "TongueLeft", "TongueRight", "TongueTwistLeft", "TongueTwistRight", "NeckFlexLeft", "NeckFlexRight",
        };

        /// <summary>"Left" / "Right" if the UE key moves only one half of the face, else null.</summary>
        public static string SideOf(string key) =>
            DirectionalKeys.Contains(key) ? null :
            key.EndsWith("Left", StringComparison.Ordinal) ? "Left" :
            key.EndsWith("Right", StringComparison.Ordinal) ? "Right" : null;

        /// <summary>The other half of a side-specific key (EyeClosedLeft -> EyeClosedRight).</summary>
        public static string Mirror(string key) =>
            SideOf(key) == "Left" ? key.Substring(0, key.Length - 4) + "Right" :
            SideOf(key) == "Right" ? key.Substring(0, key.Length - 5) + "Left" : null;
    }
}
