using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Offscreen camera in the session's preview scene. Framing follows the head bone and the face mesh;
    /// lighting is a fixed directional light, so base and target images differ only by the blendshape.
    /// </summary>
    public sealed class Capture : IDisposable
    {
        public const int Size = 512;
        public static readonly (string name, float yaw)[] Angles = { ("front", 0f), ("45", 45f) };

        /// <summary>The oblique view looks at the side of the face the key moves (avatar's left = negative yaw).</summary>
        public static float YawFor(string angle, float yaw, string key) =>
            angle == "45" && Rules.SideOf(key) == "Left" ? -yaw : yaw;

        readonly AvatarSession _s;
        readonly GameObject _cameraGo, _lightGo;
        readonly Camera _camera;
        readonly RenderTexture _rt;
        readonly Texture2D _readback;
        readonly SkinnedMeshRenderer _face;
        readonly List<Renderer> _hidden = new List<Renderer>();
        Vector3 _centre;
        float _distance;

        public Vector3 Centre => _centre;
        public Camera Camera => _camera;

        public Capture(AvatarSession s, SkinnedMeshRenderer face, bool faceOnly = true)
        {
            _s = s;
            _face = face;
            _cameraGo = new GameObject("FTForgeCamera");
            UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(_cameraGo, s.Scene);
            _camera = _cameraGo.AddComponent<Camera>();
            _camera.scene = s.Scene;
            _camera.enabled = false;
            _camera.clearFlags = CameraClearFlags.SolidColor;
            _camera.backgroundColor = new Color(0.5f, 0.5f, 0.5f, 1f);
            _camera.fieldOfView = 20f;
            _camera.nearClipPlane = 0.01f;
            _camera.farClipPlane = 10f;
            _rt = new RenderTexture(Size, Size, 24, RenderTextureFormat.ARGB32) { antiAliasing = 4 };
            _camera.targetTexture = _rt;
            _readback = new Texture2D(Size, Size, TextureFormat.RGB24, false);

            _lightGo = new GameObject("FTForgeLight");
            UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(_lightGo, s.Scene);
            var light = _lightGo.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1f;
            light.color = Color.white;
            // From the front, slightly above and to the avatar's right.
            _lightGo.transform.rotation = s.Root.transform.rotation * Quaternion.Euler(20f, 200f, 0f);

            if (faceOnly)
                foreach (var r in s.Root.GetComponentsInChildren<Renderer>())
                    if (r != face && r.enabled) { r.enabled = false; _hidden.Add(r); }

            Frame();
        }

        /// <summary>Frames the part of the face mesh around the head bone.</summary>
        void Frame()
        {
            var head = _s.Head;
            var world = MeshSampler.BakeWorld(_face);
            Vector3 h = head != null ? head.position : world.Aggregate(Vector3.zero, (a, b) => a + b) / world.Length;
            // Head vertices: above the head bone minus a margin and close to it horizontally.
            var pts = world.Where(p => p.y > h.y - 0.05f && new Vector2(p.x - h.x, p.z - h.z).magnitude < 0.2f).ToList();
            if (pts.Count < 10) pts = world.ToList();
            var b = new Bounds(pts[0], Vector3.zero);
            foreach (var p in pts) b.Encapsulate(p);
            _centre = b.center;
            float extent = Mathf.Max(b.size.x, b.size.y) * 0.6f;
            _distance = extent / Mathf.Tan(_camera.fieldOfView * 0.5f * Mathf.Deg2Rad);
        }

        public void Place(float yaw)
        {
            var root = _s.Root.transform;
            Vector3 dir = Quaternion.AngleAxis(yaw, root.up) * root.forward; // camera sits in front of the face
            _cameraGo.transform.position = _centre + dir * _distance;
            _cameraGo.transform.rotation = Quaternion.LookRotation(-dir, root.up);
        }

        // Skinned renderers only re-skin during the player loop, which does not run for an offscreen render
        // in the editor. The face is therefore drawn through a baked proxy that reflects the current weights.
        GameObject _proxyGo;
        Mesh _proxyMesh;

        void UpdateProxy()
        {
            if (_proxyGo == null)
            {
                _proxyGo = new GameObject("FTForgeFaceProxy");
                UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(_proxyGo, _s.Scene);
                _proxyGo.AddComponent<MeshFilter>();
                var mr = _proxyGo.AddComponent<MeshRenderer>();
                mr.sharedMaterials = _face.sharedMaterials;
                _proxyMesh = new Mesh();
            }
            _face.BakeMesh(_proxyMesh, true);
            _proxyGo.GetComponent<MeshFilter>().sharedMesh = _proxyMesh;
            var t = _face.transform;
            _proxyGo.transform.SetPositionAndRotation(t.position, t.rotation);
            _proxyGo.transform.localScale = Vector3.one; // BakeMesh(useScale: true) already applied the scale
            _face.enabled = false;
        }

        public Texture2D Render(float yaw)
        {
            Place(yaw);
            UpdateProxy();
            _camera.Render();
            _face.enabled = true;
            var prev = RenderTexture.active;
            RenderTexture.active = _rt;
            _readback.ReadPixels(new Rect(0, 0, Size, Size), 0, 0);
            _readback.Apply();
            RenderTexture.active = prev;
            var copy = new Texture2D(Size, Size, TextureFormat.RGB24, false);
            copy.SetPixels32(_readback.GetPixels32());
            copy.Apply();
            return copy;
        }

        public void Dispose()
        {
            foreach (var r in _hidden) if (r != null) r.enabled = true;
            if (_proxyGo != null) UnityEngine.Object.DestroyImmediate(_proxyGo);
            if (_proxyMesh != null) UnityEngine.Object.DestroyImmediate(_proxyMesh);
            _camera.targetTexture = null;
            UnityEngine.Object.DestroyImmediate(_rt);
            UnityEngine.Object.DestroyImmediate(_readback);
            UnityEngine.Object.DestroyImmediate(_cameraGo);
            UnityEngine.Object.DestroyImmediate(_lightGo);
        }
    }
}
