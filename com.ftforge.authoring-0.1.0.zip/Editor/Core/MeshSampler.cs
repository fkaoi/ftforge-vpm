using System.Collections.Generic;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Measures blendshape motion in world space (skinning included) so sides and magnitudes
    /// are judged the way the avatar actually looks.
    /// </summary>
    public static class MeshSampler
    {
        public static Vector3[] BakeWorld(SkinnedMeshRenderer r)
        {
            var baked = new Mesh();
            r.BakeMesh(baked, true);
            var v = baked.vertices;
            var m = r.transform.localToWorldMatrix;
            for (int i = 0; i < v.Length; i++) v[i] = m.MultiplyPoint3x4(v[i]);
            Object.DestroyImmediate(baked);
            return v;
        }

        /// <summary>World-space displacement of every vertex when only <paramref name="shape"/> is at 100.</summary>
        public static Vector3[] WorldDelta(SkinnedMeshRenderer r, int shape)
        {
            var weights = SaveWeights(r);
            for (int i = 0; i < weights.Length; i++) r.SetBlendShapeWeight(i, 0f);
            var a = BakeWorld(r);
            r.SetBlendShapeWeight(shape, 100f);
            var b = BakeWorld(r);
            RestoreWeights(r, weights);
            for (int i = 0; i < a.Length; i++) b[i] -= a[i];
            return b;
        }

        public static float[] SaveWeights(SkinnedMeshRenderer r)
        {
            var w = new float[r.sharedMesh.blendShapeCount];
            for (int i = 0; i < w.Length; i++) w[i] = r.GetBlendShapeWeight(i);
            return w;
        }

        public static void RestoreWeights(SkinnedMeshRenderer r, float[] w)
        {
            for (int i = 0; i < w.Length; i++) r.SetBlendShapeWeight(i, w[i]);
        }

        public struct MotionStats
        {
            public int movedVertices;
            public float maxDisplacement;     // metres
            public float leftShare, rightShare; // share of total displacement on the avatar's left/right
            public Vector3 centroid;           // displacement-weighted, avatar space (x = right, y = up, z = forward)
        }

        /// <summary>
        /// Summarises a world-space delta relative to the avatar: <paramref name="origin"/> is the head position,
        /// <paramref name="right"/> the avatar's right direction. A small dead zone around the centre line counts as neither side.
        /// </summary>
        public static MotionStats Summarise(Vector3[] basePos, Vector3[] delta, Transform avatarRoot, Vector3 origin, float threshold = 1e-5f, float centreDeadZone = 0.002f)
        {
            var s = new MotionStats();
            float total = 0, left = 0, right = 0;
            Vector3 c = Vector3.zero;
            for (int i = 0; i < delta.Length; i++)
            {
                float d = delta[i].magnitude;
                if (d < threshold) continue;
                s.movedVertices++;
                if (d > s.maxDisplacement) s.maxDisplacement = d;
                Vector3 local = avatarRoot.InverseTransformDirection(basePos[i] - origin);
                total += d;
                c += local * d;
                if (local.x > centreDeadZone) right += d;
                else if (local.x < -centreDeadZone) left += d;
            }
            if (total > 0)
            {
                s.leftShare = left / total;
                s.rightShare = right / total;
                s.centroid = c / total;
            }
            return s;
        }
    }
}
