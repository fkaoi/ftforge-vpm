using System.Collections.Generic;
using System.Linq;
using FTForge.Adapters;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Face tracking settings are written by <see cref="FTForge.ShapeApply.Apply"/> (shared with the NDMF pass);
    /// this reads back what was written and measures it. All SDK access goes through the adapter.
    /// </summary>
    public static class DescriptorWriter
    {
        public sealed class Outcome
        {
            public int mappedKeys;
            public List<string> meshes = new List<string>();
            public List<string> unresolved = new List<string>();
            public int? operations;
            public List<string> log = new List<string>();
        }

        public static Outcome Measure(AvatarSession s, List<string> applyLog)
        {
            var state = VrcFaceTrackingAdapter.Read(s.Descriptor);
            var o = new Outcome
            {
                mappedKeys = state.mappedKeys,
                meshes = state.meshes,
                unresolved = VrcFaceTrackingAdapter.UnresolvedBlendshapes(s.Descriptor),
                log = applyLog ?? new List<string>(),
            };
            try { o.operations = VrcFaceTrackingAdapter.MeasureOperations(s.Root); }
            catch (System.Exception e) { Debug.LogWarning("[FTForge] performance stats unavailable: " + e.Message); }
            return o;
        }
    }
}
