using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace FTForge.Core
{
    /// <summary>
    /// Runs Blender in background mode on raw Unity mesh arrays and returns per-vertex position deltas.
    /// No FBX is involved, so vertex order and count always match the Unity mesh.
    /// </summary>
    public static class BlenderBridge
    {
        public const string PathPrefKey = "FTForge.BlenderPath";
        const string DefaultPath = @"C:\Program Files\Blender Foundation\Blender 4.4\blender.exe";
        static readonly string Script = Path.GetFullPath(Rules.PackageRoot + "/Blender~/ftforge_ops.py");

        public static string BlenderPath
        {
            get => EditorPrefs.GetString(PathPrefKey, DefaultPath);
            set => EditorPrefs.SetString(PathPrefKey, value);
        }

        [Serializable] public sealed class Op
        {
            public string op; public string source; public string side; public float falloff; public string output;
            public string seeds, disp, metric, visible, proj; public float radius, spatial; public int smooth = 3;   // push
        }
        [Serializable] class Shapes { public List<string> names = new List<string>(); public List<string> files = new List<string>(); }
        [Serializable] class Result { public bool ok; public string error; public string blender; }

        public sealed class Job
        {
            public SkinnedMeshRenderer renderer;
            public float[] sideCoord;            // per vertex, metres; > 0 = avatar's right
            public List<string> sourceShapes = new List<string>();
            public List<Op> ops = new List<Op>();
            public bool saveBlend;
            public int[] weld;                  // vertex -> welded id (push)
            public int[] edges;                 // welded id pairs, flattened (push)
            public Dictionary<string, float[]> files = new Dictionary<string, float[]>(); // extra float arrays by file name
        }

        /// <summary>Returns output name -> mesh-space delta per vertex.</summary>
        public static Dictionary<string, Vector3[]> Run(Job job, string workDir, int timeoutSeconds = 300)
        {
            if (!File.Exists(BlenderPath)) throw new FileNotFoundException($"Blender not found at '{BlenderPath}'. Set EditorPrefs '{PathPrefKey}'.");
            if (Directory.Exists(workDir)) Directory.Delete(workDir, true);
            Directory.CreateDirectory(workDir);

            var mesh = job.renderer.sharedMesh;
            int n = mesh.vertexCount;
            WriteVectors(Path.Combine(workDir, "positions.f32"), mesh.vertices);
            var tris = mesh.triangles;
            WriteInts(Path.Combine(workDir, "triangles.i32"), tris);
            WriteFloats(Path.Combine(workDir, "side.f32"), job.sideCoord);

            var shapeEntries = new List<string>();
            foreach (var name in job.sourceShapes.Distinct())
            {
                string file = "src_" + shapeEntries.Count + ".f32";
                WriteVectors(Path.Combine(workDir, file), ShapeDelta(mesh, name));
                shapeEntries.Add($"\"{Escape(name)}\": \"{file}\"");
            }

            foreach (var kv in job.files) WriteFloats(Path.Combine(workDir, kv.Key), kv.Value);
            string graph = "";
            if (job.weld != null)
            {
                WriteInts(Path.Combine(workDir, "weld.i32"), job.weld);
                WriteInts(Path.Combine(workDir, "edges.i32"), job.edges);
                graph = ", \"graph\": {\"weld\": \"weld.i32\", \"edges\": \"edges.i32\"}";
            }

            // job.json is written by hand: JsonUtility cannot serialise dictionaries.
            string ops = string.Join(",", job.ops.Select(JsonUtility.ToJson));
            string json = "{" +
                          $"\"vertexCount\": {n}, \"triangleCount\": {tris.Length / 3}, \"saveBlend\": {(job.saveBlend ? "true" : "false")}," +
                          "\"inputs\": {\"positions\": \"positions.f32\", \"triangles\": \"triangles.i32\", \"side\": \"side.f32\", " +
                          "\"shapes\": {" + string.Join(", ", shapeEntries) + "}" + graph + "}," +
                          "\"ops\": [" + ops + "]}";
            File.WriteAllText(Path.Combine(workDir, "job.json"), json);

            var psi = new ProcessStartInfo(BlenderPath, $"-b --factory-startup -P \"{Script}\" -- \"{workDir}\"")
            {
                UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
            };
            string stdout, stderr;
            using (var p = Process.Start(psi))
            {
                var outTask = p.StandardOutput.ReadToEndAsync();
                var errTask = p.StandardError.ReadToEndAsync();
                if (!p.WaitForExit(timeoutSeconds * 1000)) { p.Kill(); throw new TimeoutException("Blender timed out"); }
                stdout = outTask.Result; stderr = errTask.Result;
            }
            File.WriteAllText(Path.Combine(workDir, "blender.log"), stdout + "\n--- stderr ---\n" + stderr);

            string resultPath = Path.Combine(workDir, "result.json");
            if (!File.Exists(resultPath)) throw new Exception("Blender produced no result. See " + Path.Combine(workDir, "blender.log"));
            var result = JsonUtility.FromJson<Result>(File.ReadAllText(resultPath));
            if (!result.ok) throw new Exception("Blender job failed:\n" + result.error);

            var outputs = new Dictionary<string, Vector3[]>();
            foreach (var op in job.ops)
            {
                var d = ReadVectors(Path.Combine(workDir, $"out_{op.output}.f32"));
                if (d.Length != n) throw new Exception($"Blender returned {d.Length} vertices for {op.output}, expected {n}");
                outputs[op.output] = d;
            }
            Debug.Log($"[FTForge] Blender {result.blender}: {outputs.Count} shape(s) from {mesh.name}");
            return outputs;
        }

        /// <summary>Mesh-space position delta of a blendshape's last (100%) frame.</summary>
        public static Vector3[] ShapeDelta(Mesh mesh, string name)
        {
            int index = mesh.GetBlendShapeIndex(name);
            if (index < 0) throw new ArgumentException($"Blendshape '{name}' not found on {mesh.name}");
            var d = new Vector3[mesh.vertexCount];
            mesh.GetBlendShapeFrameVertices(index, mesh.GetBlendShapeFrameCount(index) - 1, d, null, null);
            return d;
        }

        static string Escape(string s) => s.Replace("\\", "\\\\").Replace("\"", "\\\"");

        public static void WriteVectors(string path, Vector3[] v)
        {
            var f = new float[v.Length * 3];
            for (int i = 0; i < v.Length; i++) { f[i * 3] = v[i].x; f[i * 3 + 1] = v[i].y; f[i * 3 + 2] = v[i].z; }
            WriteFloats(path, f);
        }

        public static void WriteFloats(string path, float[] f)
        {
            var bytes = new byte[f.Length * 4];
            Buffer.BlockCopy(f, 0, bytes, 0, bytes.Length);
            File.WriteAllBytes(path, bytes);
        }

        static void WriteInts(string path, int[] a)
        {
            var bytes = new byte[a.Length * 4];
            Buffer.BlockCopy(a, 0, bytes, 0, bytes.Length);
            File.WriteAllBytes(path, bytes);
        }

        public static Vector3[] ReadVectors(string path)
        {
            var bytes = File.ReadAllBytes(path);
            var f = new float[bytes.Length / 4];
            Buffer.BlockCopy(bytes, 0, f, 0, bytes.Length);
            var v = new Vector3[f.Length / 3];
            for (int i = 0; i < v.Length; i++) v[i] = new Vector3(f[i * 3], f[i * 3 + 1], f[i * 3 + 2]);
            return v;
        }
    }
}
