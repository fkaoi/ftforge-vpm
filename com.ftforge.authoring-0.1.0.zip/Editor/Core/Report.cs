using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace FTForge.Core
{
    public static class Report
    {
        public static void WriteHtml(string path, AnalysisReport analysis, List<KeyEvaluation> evals, List<GeneratedShape> generated,
            DescriptorWriter.Outcome outcome, FaceModel face, FTForgeProfile profile, IEnumerable<string> notes)
        {
            string H(string s) => WebUtility.HtmlEncode(s ?? "");
            var genByKey = generated.ToDictionary(g => g.key);
            var sb = new StringBuilder();
            sb.Append(@"<!doctype html><html lang=""ja""><head><meta charset=""utf-8""><meta name=""viewport"" content=""width=device-width,initial-scale=1"">
<title>FTForge Report</title><style>
:root{--bg:#fafafa;--fg:#222;--muted:#666;--line:#ddd;--card:#fff;--chip:#eee}
@media (prefers-color-scheme: dark){:root{--bg:#1b1b1b;--fg:#eee;--muted:#aaa;--line:#333;--card:#242424;--chip:#333}}
body{font-family:system-ui,sans-serif;background:var(--bg);color:var(--fg);margin:0;padding:16px}
h1{font-size:20px;margin:0 0 4px} h2{font-size:16px;margin:20px 0 6px} .muted{color:var(--muted);font-size:13px}
table{border-collapse:collapse;width:100%;margin-top:12px} th,td{border-bottom:1px solid var(--line);padding:6px;vertical-align:top;font-size:13px;text-align:left}
td img{width:150px;height:150px;display:block;border-radius:4px} .s{font-weight:700;font-size:18px;text-align:center}
.s1,.s2{color:#d33}.s3{color:#c80}.s4,.s5{color:#2a2}
.chip{display:inline-block;background:var(--chip);border-radius:10px;padding:1px 8px;margin:1px 2px 1px 0;font-size:12px}
.summary{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px}.summary div{background:var(--card);border:1px solid var(--line);border-radius:6px;padding:8px 12px}
details summary{cursor:pointer;color:var(--muted)} .wrap{overflow-x:auto} code{font-size:12px}
</style></head><body>");
            sb.Append($"<h1>FTForge Report — {H(analysis.avatar)}</h1>");
            sb.Append($"<div class=muted>face mesh: {H(analysis.faceMesh)} · IOD {face.Iod * 1000:F1} mm · {H(face.LandmarkNote)} · run {H(profile.lastRun)}</div>");
            sb.Append("<div class=summary>");
            void Card(string label, object v) => sb.Append($"<div>{H(label)}<br><b>{H(v?.ToString())}</b></div>");
            Card("Existing", analysis.existing); Card("Alias", analysis.alias); Card("Generated", generated.Count); Card("Unassigned", analysis.unavailable);
            Card("Mapped keys", outcome.mappedKeys); Card("FT meshes", outcome.meshes.Count); Card("FT operations (SDK)", outcome.operations?.ToString() ?? "n/a");
            Card("Unresolved names", outcome.unresolved.Count); Card("Needs review (≤3)", evals.Count(e => e.score <= 3));
            Card("Approved", profile.keys.Count(k => k.approved));
            sb.Append("</div>");
            foreach (var n in notes) sb.Append($"<p class=muted>{H(n)}</p>");

            sb.Append("<div class=wrap><table><tr><th>Key</th><th>Base</th><th>Result</th><th>Base 45°</th><th>Result 45°</th><th>Heatmap</th><th>Score</th><th>Details</th></tr>");
            foreach (var e in evals.OrderBy(e => e.score).ThenBy(e => e.key))
            {
                var entry = profile.Get(e.key);
                string img(string f) => $"<img loading=lazy src=\"img/{H(f)}\" alt=\"{H(f)}\">";
                sb.Append($"<tr><td><b>{H(e.key)}</b><br><span class=chip>{H(e.status)}</span><span class=chip>{H(e.source)}</span>");
                if (entry != null && entry.approved) sb.Append("<span class=chip>approved</span>");
                if (entry != null && entry.mode != FTForgeProfile.OverrideMode.Auto) sb.Append($"<span class=chip>override: {H(entry.mode.ToString())}</span>");
                sb.Append($"<br><code>{H(e.rule ?? e.shape)}</code></td>");
                sb.Append($"<td>{img(e.baseFront)}</td><td>{img($"{e.key}_front.png")}</td><td>{img(e.base45)}</td><td>{img($"{e.key}_45.png")}</td><td>{img($"{e.key}_heat.png")}</td>");
                sb.Append($"<td class=\"s s{e.score}\">{e.score}</td><td class=muted>max {e.maxMm:F1} mm ({e.maxIod:F2} IOD) · L {e.leftShare:P0} / R {e.rightShare:P0}<br>");
                sb.Append($"area {e.regionShare:P0} · visible {e.visibleShare:P0} · crease {e.crease:F1} · {e.imageChangedPixels} px changed<br>{H(string.Join("; ", e.issues))}");
                if (genByKey.TryGetValue(e.key, out var g) && g.tried.Count > 1)
                    sb.Append($"<details><summary>{g.tried.Count} candidates</summary><ul>{string.Concat(g.tried.Select(t => "<li><code>" + H(t) + "</code></li>"))}</ul></details>");
                sb.Append("</td></tr>");
            }
            sb.Append("</table></div>");

            var unavailable = analysis.keys.Where(k => k.status == nameof(KeyStatus.Unavailable)).ToList();
            sb.Append($"<h2>Unassigned keys ({unavailable.Count})</h2><p class=muted>");
            sb.Append(string.Join(", ", unavailable.Select(k => H(k.key) + (k.note != null && (k.note.StartsWith("rejected") || k.source == "disabled" || k.note.StartsWith("all candidates")) ? " <i>(" + H(k.note) + ")</i>" : ""))));
            sb.Append("</p>");
            if (outcome.unresolved.Count > 0)
                sb.Append("<h2>Unresolved mappings (SDK validator)</h2><p class=muted>" + H(string.Join(", ", outcome.unresolved)) + "</p>");
            sb.Append("</body></html>");
            File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
        }
    }
}
