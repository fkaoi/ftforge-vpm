using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using FTForge.Bridge;
using UnityEditor;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// One call: load avatar + profile → analyse → generate (stages B/C, best of several candidates) →
    /// apply to a mesh copy → configure face tracking → capture → evaluate → HTML report → store results in the profile.
    /// Entry points: bridge commands "run"/"phase1", menu Tools/FTForge, or batchmode
    /// <c>-executeMethod FTForge.Core.Pipeline.RunFromCommandLine -ftforgePrefab &lt;path&gt;</c>.
    /// </summary>
    public static class Pipeline
    {
        public const string WorkFolder = "Assets/FTForge_Work";
        public const string DefaultPrefab = "Assets/Amatousagi/Chocolat/Chocolat.prefab";

        // Image context: keys that only make sense on top of another key are captured with that key at 100.
        static readonly Dictionary<string, string> CaptureContext = new Dictionary<string, string>
        {
            { "MouthClosed", "JawOpen" },
        };
        static string ContextOf(string key) =>
            CaptureContext.TryGetValue(key, out var c) ? c : key.StartsWith("Tongue") && key != "TongueOut" ? "TongueOut" : null;

        [BridgeCommand("phase1")]
        static string Bridge1(string prefabPath) => Run(string.IsNullOrEmpty(prefabPath) ? DefaultPrefab : prefabPath);

        [BridgeCommand("run")]
        static string BridgeRun(string prefabPath) => Run(string.IsNullOrEmpty(prefabPath) ? DefaultPrefab : prefabPath);

        [MenuItem("Tools/FTForge/Run on Selected Prefab")]
        static void Menu()
        {
            string path = Selection.activeObject != null ? AssetDatabase.GetAssetPath(Selection.activeObject) : DefaultPrefab;
            if (Selection.activeObject is FTForgeProfile p && p.avatarPrefab != null) path = AssetDatabase.GetAssetPath(p.avatarPrefab);
            if (!path.EndsWith(".prefab")) path = DefaultPrefab;
            Debug.Log("[FTForge] " + Run(path));
        }

        public static void RunFromCommandLine()
        {
            var args = Environment.GetCommandLineArgs();
            int i = Array.IndexOf(args, "-ftforgePrefab");
            string path = i >= 0 && i + 1 < args.Length ? args[i + 1] : DefaultPrefab;
            try { Debug.Log("[FTForge] " + Run(path)); EditorApplication.Exit(0); }
            catch (Exception e) { Debug.LogException(e); EditorApplication.Exit(1); }
        }

        public static string ReportPath(string avatarName) => Path.Combine(Commands.OutputDir(avatarName), "report", "index.html");

        public static string Run(string prefabPath)
        {
            var log = new StringBuilder();
            var sw = System.Diagnostics.Stopwatch.StartNew();
            void Step(string s) { log.AppendLine($"[{sw.Elapsed.TotalSeconds,6:F1}s] {s}"); }

            using var s = new AvatarSession(prefabPath);
            var profile = ProfileStore.LoadOrCreate(s.Prefab);
            string outDir = Commands.OutputDir(s.Prefab.name);
            string reportDir = Path.Combine(outDir, "report");
            if (Directory.Exists(reportDir)) Directory.Delete(reportDir, true);
            Directory.CreateDirectory(Path.Combine(reportDir, "img"));

            // 1. analyse
            var analysis = Analyzer.Run(s, profile);
            Step($"analysed: existing={analysis.existing} alias={analysis.alias} synth={analysis.synthesizable} unavailable={analysis.unavailable} (profile {AssetDatabase.GetAssetPath(profile)})");

            // 2. generate (stages B/C)
            var renderers = s.Renderers.ToList();
            var face = Analyzer.FindFaceMesh(s, renderers, profile);
            var faceModel = new FaceModel(s, face);
            var resolve = Analyzer.Resolver(s, analysis, face);
            var generated = Synthesizer.Run(s, analysis, faceModel, profile, resolve, Path.Combine(outDir, "work"));
            Step($"generated {generated.Count} shape(s) from {generated.Sum(g => g.tried.Count)} candidates");
            File.WriteAllText(Path.Combine(outDir, "analysis.json"), JsonUtility.ToJson(analysis, true));

            // 3. distributable data: sparse deltas + mappings (no original mesh data)
            string avatarFolder = $"{WorkFolder}/{Synthesizer.Sanitize(s.Prefab.name)}";
            var data = ShapeApplier.Build(s, analysis, generated);
            data = SaveData(data, $"{avatarFolder}/{Synthesizer.Sanitize(s.Prefab.name)}_FTForgeData.asset");
            Step($"data: {data.meshes.Sum(m => m.shapes.Count)} shapes ({data.meshes.Sum(m => m.shapes.Sum(x => x.indices.Length))} vertex deltas), {data.mappings.Count} mappings → {AssetDatabase.GetAssetPath(data)}");

            // 4. variant prefab = original avatar + FTForge Apply (applied at build time by NDMF)
            string variantPath = $"{avatarFolder}/{Synthesizer.Sanitize(s.Prefab.name)}_FTForge.prefab";
            SaveVariant(s, data, variantPath);
            string oldMesh = $"{avatarFolder}/{Synthesizer.Sanitize(face.sharedMesh.name)}_FTForge.asset"; // Phase 1/2 preview mesh, no longer used
            if (AssetDatabase.LoadAssetAtPath<Mesh>(oldMesh) != null) AssetDatabase.DeleteAsset(oldMesh);

            // preview in the session through the same code the build uses
            var applyLog = ShapeApply.Apply(s.Root.transform, data, true);
            var outcome = DescriptorWriter.Measure(s, applyLog);
            Step($"applied (preview): {string.Join("; ", applyLog)}; unresolved={outcome.unresolved.Count}, FT operations={outcome.operations?.ToString() ?? "n/a"}; variant {variantPath}");

            // 5+6. capture and evaluate on the final meshes
            var evals = CaptureAndEvaluate(s, analysis, generated, reportDir, profile);
            Step($"captured and evaluated {evals.Count} key(s); needs review: {evals.Count(e => e.score <= 3)}");

            var unapproved = profile.keys.Count(k => !k.approved && analysis.keys.Any(a => a.key == k.key && a.status != nameof(KeyStatus.Unavailable)));
            string summary = $"mapped {outcome.mappedKeys} (alias {analysis.alias + analysis.existing}, generated {generated.Count}), unassigned {analysis.unavailable}, needs review {evals.Count(e => e.score <= 3)}, not approved {unapproved}, FT ops {outcome.operations?.ToString() ?? "n/a"}";
            ProfileStore.StoreResults(profile, analysis, evals, summary);

            var notes = new List<string>
            {
                "Penetration checks (eyelid/eyeball, lips/teeth) are not implemented yet.",
                $"Profile: {AssetDatabase.GetAssetPath(profile)} · Preview: {variantPath}",
            };
            Report.WriteHtml(Path.Combine(reportDir, "index.html"), analysis, evals, generated, outcome, faceModel, profile, notes);
            Step($"report: {Path.Combine(reportDir, "index.html")}");
            log.AppendLine("  " + summary);

            foreach (var e in evals.OrderBy(e => e.score).ThenBy(e => e.key))
                log.AppendLine($"  {e.score} {e.key,-22} {(e.rule ?? e.shape),-44} max={e.maxMm:F1}mm L={e.leftShare:F2} R={e.rightShare:F2} area={e.regionShare:F2} vis={e.visibleShare:F2} crease={e.crease:F1} px={e.imageChangedPixels} {string.Join("; ", e.issues)}");
            return log.ToString();
        }

        static List<KeyEvaluation> CaptureAndEvaluate(AvatarSession s, AnalysisReport analysis, List<GeneratedShape> generated, string reportDir, FTForgeProfile profile)
        {
            var evals = new List<KeyEvaluation>();
            var renderers = s.Renderers.ToList();
            var face = Analyzer.FindFaceMesh(s, renderers, profile);
            var models = new Dictionary<SkinnedMeshRenderer, FaceModel>();
            FaceModel Model(SkinnedMeshRenderer r) => models.TryGetValue(r, out var m) ? m : models[r] = new FaceModel(s, r);
            var genByKey = generated.ToDictionary(g => g.key);
            var mapped = analysis.keys.Where(k => k.status != nameof(KeyStatus.Unavailable)).ToList();
            var shapeOfKey = mapped.ToDictionary(k => k.key, k => (renderer: s.FindRenderer(k.meshPath), shape: k.shape));

            s.ResetBlendShapes();
            using var cap = new Capture(s, face);
            var baseImg = new Dictionary<string, Texture2D>();
            void SetContext(string ctx, float w)
            {
                if (ctx == null || !shapeOfKey.TryGetValue(ctx, out var c)) return;
                int i = c.renderer.sharedMesh.GetBlendShapeIndex(c.shape);
                if (i >= 0) c.renderer.SetBlendShapeWeight(i, w);
            }
            Texture2D Base(string ctx, string angle, float yaw)
            {
                string id = $"{ctx ?? "_"}_{angle}_{yaw}";
                if (baseImg.TryGetValue(id, out var t)) return t;
                SetContext(ctx, 100f);
                t = baseImg[id] = cap.Render(yaw);
                SetContext(ctx, 0f);
                return t;
            }

            foreach (var k in mapped)
            {
                var r = shapeOfKey[k.key].renderer;
                int index = r.sharedMesh.GetBlendShapeIndex(k.shape);
                KeyEvaluation e;
                var model = Model(r);
                var ev = new Evaluator(model);
                if (index < 0) { e = new KeyEvaluation { key = k.key, score = 1 }; e.issues.Add("shape missing on mesh"); evals.Add(e); continue; }
                var delta = model.ToAvatarDelta(BlenderBridge.ShapeDelta(r.sharedMesh, k.shape));
                Vector3[] reference = null;
                if (genByKey.TryGetValue(k.key, out var g)) reference = g.reference;
                e = ev.EvaluateDelta(k.key, delta, reference);
                e.shape = k.shape; e.status = k.status; e.source = k.source; e.rule = k.rule; e.meshPath = k.meshPath;
                e.candidatesTried = g?.tried.Count ?? 0;

                string ctx = ContextOf(k.key);
                foreach (var (angle, yaw0) in Capture.Angles)
                {
                    float yaw = Capture.YawFor(angle, yaw0, k.key);
                    var b = Base(ctx, angle, yaw);
                    string baseFile = $"_base_{(ctx ?? "neutral")}_{angle}{(yaw < 0 ? "L" : "")}.png";
                    string basePath = Path.Combine(reportDir, "img", baseFile);
                    if (!File.Exists(basePath)) Save(b, basePath);
                    SetContext(ctx, 100f);
                    r.SetBlendShapeWeight(index, 100f);
                    var img = cap.Render(yaw);
                    r.SetBlendShapeWeight(index, 0f);
                    SetContext(ctx, 0f);
                    Save(img, Path.Combine(reportDir, "img", $"{k.key}_{angle}.png"));
                    if (angle == "front")
                    {
                        cap.Place(0f);
                        var heat = ev.Heatmap(b, img, cap.Camera, e);
                        Save(heat, Path.Combine(reportDir, "img", $"{k.key}_heat.png"));
                        UnityEngine.Object.DestroyImmediate(heat);
                    }
                    UnityEngine.Object.DestroyImmediate(img);
                    if (angle == "front") e.baseFront = baseFile; else e.base45 = baseFile;
                }
                Evaluator.Score(e);
                evals.Add(e);
            }
            Evaluator.CheckPairs(evals);
            foreach (var t in baseImg.Values) UnityEngine.Object.DestroyImmediate(t);
            return evals;
        }

        static void Save(Texture2D t, string path) => File.WriteAllBytes(path, t.EncodeToPNG());

        static FTForgeShapeData SaveData(FTForgeShapeData data, string path)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            var existing = AssetDatabase.LoadAssetAtPath<FTForgeShapeData>(path);
            if (existing == null) { AssetDatabase.CreateAsset(data, path); return data; }
            EditorUtility.CopySerialized(data, existing);
            UnityEngine.Object.DestroyImmediate(data);
            EditorUtility.SetDirty(existing);
            AssetDatabase.SaveAssetIfDirty(existing);
            return existing;
        }

        /// <summary>Prefab variant of the untouched avatar with an FTForge Apply child pointing at the data.</summary>
        static void SaveVariant(AvatarSession s, FTForgeShapeData data, string path)
        {
            var inst = (GameObject)PrefabUtility.InstantiatePrefab(s.Prefab, s.Scene);
            try
            {
                var go = new GameObject("FTForge");
                go.transform.SetParent(inst.transform, false);
                go.AddComponent<FTForgeApply>().data = data;
                PrefabUtility.SaveAsPrefabAsset(inst, path);
            }
            finally { UnityEngine.Object.DestroyImmediate(inst); }
        }
    }
}
