using System.IO;
using System.Linq;
using System.Text;
using FTForge.Bridge;
using UnityEditor;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Writes the distributable package: shape data (deltas + mappings), a drop-in prefab with FTForge Apply,
    /// and a readme. No mesh, FBX, texture or prefab of the original avatar is included.
    /// </summary>
    public static class Exporter
    {
        public const string ExportRoot = "Assets/FTForge_Export";

        /// <summary>VPM listing URL printed in the buyer README (EditorPrefs "FTForge.VpmListingUrl").</summary>
        public static string VpmListingUrl
        {
            get => EditorPrefs.GetString("FTForge.VpmListingUrl", "");
            set => EditorPrefs.SetString("FTForge.VpmListingUrl", value);
        }

        [BridgeCommand("export")]
        static string ExportCommand(string prefabPath) => Export(AssetDatabase.LoadAssetAtPath<GameObject>(string.IsNullOrEmpty(prefabPath) ? Pipeline.DefaultPrefab : prefabPath));

        public static string Export(GameObject avatarPrefab)
        {
            string name = Synthesizer.Sanitize(avatarPrefab.name);
            string srcData = $"{Pipeline.WorkFolder}/{name}/{name}_FTForgeData.asset";
            var source = AssetDatabase.LoadAssetAtPath<FTForgeShapeData>(srcData)
                         ?? throw new FileNotFoundException($"Run FTForge on {avatarPrefab.name} first ({srcData} missing).");

            string folder = $"{ExportRoot}/{name}";
            Directory.CreateDirectory(folder);
            string dataPath = $"{folder}/{name}_FTForgeData.asset";
            AssetDatabase.DeleteAsset(dataPath);
            AssetDatabase.CopyAsset(srcData, dataPath);
            var data = AssetDatabase.LoadAssetAtPath<FTForgeShapeData>(dataPath);

            // Drop-in prefab: put it under the avatar root.
            string applyPath = $"{folder}/FTForge_{name}.prefab";
            var go = new GameObject($"FTForge_{name}");
            try
            {
                go.AddComponent<FTForgeApply>().data = data;
                PrefabUtility.SaveAsPrefabAsset(go, applyPath);
            }
            finally { Object.DestroyImmediate(go); }

            string readmePath = $"{folder}/README_FTForge.txt";
            File.WriteAllText(readmePath, Readme(avatarPrefab.name, data), new UTF8Encoding(true));
            AssetDatabase.ImportAsset(readmePath);

            // Safety: nothing but our own assets may go into the package.
            var deps = AssetDatabase.GetDependencies(new[] { dataPath, applyPath, readmePath }, true);
            var foreign = deps.Where(d => !d.StartsWith(folder + "/") && !d.StartsWith("Packages/com.ftforge.core/")).ToList();
            if (foreign.Count > 0) throw new System.InvalidOperationException("Export would include avatar assets: " + string.Join(", ", foreign));
            if (deps.Any(d => d.EndsWith(".fbx") || AssetDatabase.GetMainAssetTypeAtPath(d) == typeof(Mesh)))
                throw new System.InvalidOperationException("Export would include mesh data.");

            string outFile = Path.Combine(Commands.OutputDir(avatarPrefab.name), $"FTForge_{name}.unitypackage");
            var files = new[] { dataPath, applyPath, readmePath };
            AssetDatabase.ExportPackage(files, outFile, ExportPackageOptions.Default);
            long size = new FileInfo(outFile).Length;
            return $"exported {outFile} ({size / 1024} KB): {string.Join(", ", files)}";
        }

        static string Readme(string avatar, FTForgeShapeData data)
        {
            int shapes = data.meshes.Sum(m => m.shapes.Count);
            return
$@"FTForge フェイストラッキング対応データ — {avatar}

【内容】
- {Path.GetFileName(AssetDatabase.GetAssetPath(data))} : 追加ブレンドシェイプ {shapes} 個の差分（頂点ごとの移動量のみ）と、
  Unified Expressions {data.mappings.Count} キーの割り当て
- FTForge_{Synthesizer.Sanitize(avatar)}.prefab : アバターに入れるだけで適用されるプレハブ
元のFBX・メッシュ・テクスチャは含まれていません。

【必要なもの】
- VRChat Avatars SDK 3.10.6 以降
- NDMF（Modular Avatar などに同梱）
- FTForge（VPMパッケージ com.ftforge.core）

【FTForge の導入（初回のみ）】
1. VRChat Creator Companion（または ALCOM）の Settings → Packages → Add Repository に
   {(string.IsNullOrEmpty(VpmListingUrl) ? "（FTForge の VPM リポジトリ URL）" : VpmListingUrl)}
   を追加します。
2. プロジェクトの Manage Project で「FTForge」を追加します。
   （「FTForge Authoring」はデータを作る人向けです。使うだけなら不要です。）

【使い方】
1. この unitypackage をインポートし、FTForge_{Synthesizer.Sanitize(avatar)}.prefab を {avatar} のルート直下に入れます。
2. そのままアップロードします。ビルド時にブレンドシェイプが追加され、
   Avatar Descriptor の Face Tracking（メッシュ登録・割り当て・LipSync/Eye Gaze モード）が設定されます。
   元のアセットやシーンは変更されません。
3. 対応するメッシュと違う場合（アバターのバージョン違いなど）はビルド時にエラーを表示し、適用しません。

【注意】
- まばたきは Eyelid Type = Face Tracking に切り替わります。
- 生成元: FTForge {data.generatorVersion}
";
        }
    }
}
