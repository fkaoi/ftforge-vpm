using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>
    /// Mesh connectivity with seam duplicates welded (Unity splits vertices at UV/normal seams,
    /// which would otherwise look like holes).
    /// </summary>
    public sealed class Topology
    {
        public readonly int[] Weld;                 // vertex -> welded id
        public readonly int WeldedCount;
        public readonly List<int>[] Members;        // welded id -> vertices
        public readonly List<int>[] Neighbours;     // welded id -> welded ids
        public readonly List<List<int>> BoundaryLoops = new List<List<int>>(); // welded ids, in order

        /// <param name="splitBy">Optional deltas: coincident vertices that move differently under these stay apart
        /// (e.g. the lips along a closed mouth slit), so the slit shows up as a boundary.</param>
        public Topology(Mesh mesh, IList<Vector3[]> splitBy = null, float weldDistance = 1e-6f)
        {
            var v = mesh.vertices;
            Weld = new int[v.Length];
            var map = new Dictionary<string, int>();
            float q = 1f / weldDistance;
            string Q(Vector3 p) => $"{Mathf.RoundToInt(p.x * q)},{Mathf.RoundToInt(p.y * q)},{Mathf.RoundToInt(p.z * q)}";
            for (int i = 0; i < v.Length; i++)
            {
                var key = Q(v[i]);
                if (splitBy != null) foreach (var d in splitBy) key += "|" + Q(v[i] + d[i]);
                if (!map.TryGetValue(key, out int id)) map[key] = id = map.Count;
                Weld[i] = id;
            }
            WeldedCount = map.Count;
            Members = Enumerable.Range(0, WeldedCount).Select(_ => new List<int>()).ToArray();
            for (int i = 0; i < v.Length; i++) Members[Weld[i]].Add(i);

            var edgeUse = new Dictionary<long, int>();
            var tris = mesh.triangles;
            long Key(int a, int b) => a < b ? ((long)a << 32) | (uint)b : ((long)b << 32) | (uint)a;
            for (int t = 0; t < tris.Length; t += 3)
                for (int e = 0; e < 3; e++)
                {
                    int a = Weld[tris[t + e]], b = Weld[tris[t + (e + 1) % 3]];
                    if (a == b) continue;
                    long k = Key(a, b);
                    edgeUse[k] = edgeUse.TryGetValue(k, out int c) ? c + 1 : 1;
                }
            Neighbours = Enumerable.Range(0, WeldedCount).Select(_ => new List<int>()).ToArray();
            var boundaryAdj = new Dictionary<int, List<int>>();
            foreach (var kv in edgeUse)
            {
                int a = (int)(kv.Key >> 32), b = (int)(kv.Key & 0xffffffff);
                Neighbours[a].Add(b); Neighbours[b].Add(a);
                if (kv.Value == 1)
                {
                    if (!boundaryAdj.TryGetValue(a, out var la)) boundaryAdj[a] = la = new List<int>();
                    if (!boundaryAdj.TryGetValue(b, out var lb)) boundaryAdj[b] = lb = new List<int>();
                    la.Add(b); lb.Add(a);
                }
            }
            var seen = new HashSet<int>();
            foreach (int start in boundaryAdj.Keys)
            {
                if (seen.Contains(start)) continue;
                var loop = new List<int>();
                int prev = -1, cur = start;
                while (cur >= 0 && seen.Add(cur))
                {
                    loop.Add(cur);
                    int next = -1;
                    foreach (int n in boundaryAdj[cur]) if (n != prev && !seen.Contains(n)) { next = n; break; }
                    prev = cur; cur = next;
                }
                BoundaryLoops.Add(loop);
            }
        }
    }
}
