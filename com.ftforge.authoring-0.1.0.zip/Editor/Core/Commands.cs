using System.IO;
using System.Linq;
using System.Text;
using FTForge.Bridge;
using UnityEngine;

namespace FTForge.Core
{
    static class Commands
    {
        public static string OutputDir(string avatarName)
        {
            string dir = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "Library", "FTForge", "out", avatarName));
            Directory.CreateDirectory(dir);
            return dir;
        }

        [BridgeCommand("analyze")]
        static string Analyze(string prefabPath)
        {
            using var s = new AvatarSession(prefabPath);
            var report = Analyzer.Run(s);
            string dir = OutputDir(report.avatar);
            File.WriteAllText(Path.Combine(dir, "analysis.json"), JsonUtility.ToJson(report, true));
            return Summarise(report) + $"\nwritten: {dir}";
        }

        public static string Summarise(AnalysisReport r)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{r.avatar}: face={r.faceMesh} existing={r.existing} alias={r.alias} synth={r.synthesizable} unavailable={r.unavailable}");
            foreach (var k in r.keys.Where(k => k.status != "Unavailable"))
                sb.AppendLine($"  {k.status,-13} {k.key,-22} <- {k.shape} {(k.rule != null ? "[" + k.rule + "]" : "")} L={k.leftShare:F2} R={k.rightShare:F2} max={k.maxDisplacementMm:F1}mm");
            foreach (var k in r.keys.Where(k => k.status == "Unavailable" && k.note != null && k.note.StartsWith("rejected")))
                sb.AppendLine($"  Unavailable   {k.key,-22} {k.note}");
            return sb.ToString();
        }
    }
}
