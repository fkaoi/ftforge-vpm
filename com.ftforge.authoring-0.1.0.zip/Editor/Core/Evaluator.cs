using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FTForge.Core
{
    [Serializable]
    public sealed class KeyEvaluation
    {
        public string key, shape, status, source, rule, meshPath;
        public int movedVertices;
        public float maxMm, maxIod;          // largest displacement, in mm and in inter-ocular distances
        public float leftShare, rightShare;
        public float regionShare;            // share of motion inside the expected face half
        public float visibleShare;           // largest visible motion / largest motion
        public float crease;                 // steepness of split/mask cuts through moving skin (0 = none, >12 visible)
        public float imageChange;            // mean per-pixel change (0..1), front view
        public int imageChangedPixels;       // pixels whose colour changed noticeably, front view
        public float imageRegionShare;       // share of pixel change inside the expected face half, front view
        public bool imageChecked;
        public string baseFront, base45;     // report image file names of the matching base pose
        public int score;                    // 1..5 automatic score
        public float quality;                // finer ranking among candidates with the same score
        public int candidatesTried;
        public List<string> issues = new List<string>();
    }

    /// <summary>
    /// Automatic checks: side leakage, motion magnitude, where on the face the motion is, new creases from
    /// splits/masks, left/right pair symmetry, and (for final results) image change in the front view.
    /// Shapes are measured on vertex data, not image landmarks. Penetration checks are not implemented yet.
    /// </summary>
    public sealed class Evaluator
    {
        public enum Region { Upper, Lower, Any }

        public readonly FaceModel Face;
        public float Iod => Face.Iod;
        public string LandmarkNote => Face.LandmarkNote;

        public Evaluator(FaceModel face) { Face = face; }

        public static Region RegionOf(string key)
        {
            if (key.StartsWith("Eye") || key.StartsWith("Brow")) return Region.Upper;
            if (key.StartsWith("Jaw") || key.StartsWith("Mouth") || key.StartsWith("Lip") || key.StartsWith("Tongue")) return Region.Lower;
            return Region.Any;
        }

        /// <summary>Vertex checks on an avatar-space delta. <paramref name="reference"/> is the same recipe without masks (for crease).</summary>
        public KeyEvaluation EvaluateDelta(string key, Vector3[] delta, Vector3[] reference = null)
        {
            var e = new KeyEvaluation { key = key };
            var st = Analyzer.Summarise(Face, delta);
            e.movedVertices = st.movedVertices;
            e.maxMm = st.maxDisplacement * 1000f;
            e.maxIod = st.maxDisplacement / Iod;
            e.leftShare = st.leftShare;
            e.rightShare = st.rightShare;

            var region = RegionOf(key);
            float total = 0, inside = 0;
            for (int i = 0; i < delta.Length; i++)
            {
                float d = delta[i].magnitude;
                if (d < 1e-5f) continue;
                total += d;
                float y = Face.Rest[i].y;
                if (region == Region.Any || (region == Region.Upper ? y >= Face.MidY : y <= Face.MidY)) inside += d;
            }
            e.regionShare = total > 0 ? inside / total : 0;
            // Largest motion on visible skin relative to the largest motion overall. (A share of total motion would be
            // diluted by hidden parts that are made to follow the skin.)
            float visMax = 0;
            var visible = Face.Visible;
            for (int i = 0; i < delta.Length; i++) if (visible[i] > 0) visMax = Mathf.Max(visMax, delta[i].magnitude);
            e.visibleShare = st.maxDisplacement > 0 ? visMax / st.maxDisplacement : 0;
            e.crease = reference != null ? Crease(delta, reference) : 0f;
            return e;
        }

        /// <summary>
        /// How sharply a split or mask cuts through moving skin. The effective weight of each vertex is
        /// |result| / |reference|; across every edge we take the weight change per IOD, scaled by how much that
        /// skin moves relative to the largest motion. 99th percentile. Roughly: 10 = full cut over 0.1 IOD on
        /// strongly moving skin. 0 when the result equals the reference (no split/mask).
        /// </summary>
        float Crease(Vector3[] gen, Vector3[] reference)
        {
            float max = 0;
            foreach (var v in reference) max = Mathf.Max(max, v.magnitude);
            if (max < 1e-7f) return 0;
            float W(int i)
            {
                float r = reference[i].magnitude;
                return r < max * 1e-3f ? 0f : Mathf.Clamp01(gen[i].magnitude / r);
            }
            var g = new List<float>();
            for (int k = 0; k < Face.EdgeA.Length; k++)
            {
                int a = Face.EdgeA[k], b = Face.EdgeB[k];
                float moving = Mathf.Max(reference[a].magnitude, reference[b].magnitude) / max;
                // Both ends must move in the reference, or the weight ratio is meaningless.
                if (moving < 0.05f || Mathf.Min(reference[a].magnitude, reference[b].magnitude) < max * 1e-3f) continue;
                float len = Vector3.Distance(Face.Rest[a], Face.Rest[b]);
                if (len < 1e-6f) continue; // seam duplicates
                g.Add(Mathf.Abs(W(a) - W(b)) / len * Iod * moving);
            }
            if (g.Count == 0) return 0;
            g.Sort();
            return g[(int)(g.Count * 0.99f)];
        }

        /// <summary>Heatmap of |target - base| and the share of change inside the expected half of the image.</summary>
        public Texture2D Heatmap(Texture2D a, Texture2D b, Camera cam, KeyEvaluation e)
        {
            var pa = a.GetPixels32();
            var pb = b.GetPixels32();
            int w = a.width, h = a.height;
            Vector3 midWorld = Face.Session.Head != null ? Face.Session.Head.position : Face.Session.Root.transform.position;
            midWorld += Face.FromAvatarDir(Vector3.up * Face.MidY);
            float midRow = cam.WorldToViewportPoint(midWorld).y * h;
            var region = RegionOf(e.key);

            var heat = new Color32[pa.Length];
            double sum = 0, inside = 0;
            e.imageChangedPixels = 0;
            for (int i = 0; i < pa.Length; i++)
            {
                int d = Math.Max(Math.Abs(pa[i].r - pb[i].r), Math.Max(Math.Abs(pa[i].g - pb[i].g), Math.Abs(pa[i].b - pb[i].b)));
                float t = d / 255f;
                sum += t;
                if (d > 16) e.imageChangedPixels++;
                int row = i / w;
                if (region == Region.Any || (region == Region.Upper ? row >= midRow : row <= midRow)) inside += t;
                byte g = (byte)((pa[i].r + pa[i].g + pa[i].b) / 6);
                float k = Mathf.Clamp01(t * 4f);
                heat[i] = Color32.Lerp(new Color32(g, g, g, 255), Color32.Lerp(new Color32(255, 230, 0, 255), new Color32(255, 0, 0, 255), k), k > 0.02f ? 0.35f + 0.65f * k : 0f);
                if (Mathf.Abs(row - midRow) < 1f) heat[i] = new Color32(0, 160, 255, 255);
            }
            e.imageChecked = true;
            e.imageChange = (float)(sum / pa.Length);
            e.imageRegionShare = sum > 0 ? (float)(inside / sum) : 0;
            var tex = new Texture2D(w, h, TextureFormat.RGB24, false);
            tex.SetPixels32(heat);
            tex.Apply();
            return tex;
        }

        public static void Score(KeyEvaluation e)
        {
            e.issues.Clear();
            if (e.movedVertices == 0) { e.issues.Add("no motion"); e.score = 1; e.quality = 0; return; }
            int score = 5;
            float quality = 0;
            string side = Rules.SideOf(e.key);
            if (side != null)
            {
                float leak = side == "Left" ? e.rightShare : e.leftShare;
                quality -= leak * 10;
                if (leak > 0.2f) { score -= 3; e.issues.Add($"leaks {leak:P0} to the other side"); }
                else if (leak > 0.05f) { score -= 2; e.issues.Add($"leaks {leak:P0} to the other side"); }
            }
            quality -= (1 - e.regionShare) * 5;
            if (e.regionShare < 0.7f) { score -= 2; e.issues.Add($"only {e.regionShare:P0} of motion in the expected area"); }
            else if (e.regionShare < 0.9f) { score -= 1; e.issues.Add($"{e.regionShare:P0} of motion in the expected area"); }
            quality -= e.crease * 0.1f;
            if (e.crease > 25f) { score -= 2; e.issues.Add($"sharp cut through moving skin (crease {e.crease:F0})"); }
            else if (e.crease > 12f) { score -= 1; e.issues.Add($"visible cut through moving skin (crease {e.crease:F0})"); }
            quality -= (1 - e.visibleShare) * 2;
            // Opening the mouth is meant to reveal hidden parts; once the image shows clear change, trust the image.
            bool clearlyVisible = e.imageChecked && e.imageChangedPixels >= 300;
            if (clearlyVisible) { }
            else if (e.visibleShare < 0.15f) { score -= 2; e.issues.Add($"mostly hidden: visible skin moves {e.visibleShare:P0} of the maximum"); }
            else if (e.visibleShare < 0.35f) { score -= 1; e.issues.Add($"partly hidden: visible skin moves {e.visibleShare:P0} of the maximum"); }
            if (e.maxIod < 0.01f) { score -= 1; e.issues.Add("very small motion"); }
            if (e.maxIod > 1.2f) { score -= 1; e.issues.Add("very large motion"); }
            if (e.imageChecked)
            {
                if (e.imageChangedPixels < 30) { score -= 1; e.issues.Add($"barely visible in the front view ({e.imageChangedPixels} px)"); }
                else if (e.imageRegionShare < 0.7f) { score -= 1; e.issues.Add($"only {e.imageRegionShare:P0} of image change in the expected area"); }
            }
            e.score = Mathf.Clamp(score, 1, 5);
            e.quality = quality;
        }

        /// <summary>Left/right pairs should move about the same amount; flags both halves when they don't.</summary>
        public static void CheckPairs(List<KeyEvaluation> evals)
        {
            var byKey = evals.ToDictionary(e => e.key);
            foreach (var e in evals)
            {
                if (Rules.SideOf(e.key) != "Left") continue;
                if (!byKey.TryGetValue(Rules.Mirror(e.key), out var m)) continue;
                float hi = Mathf.Max(e.maxMm, m.maxMm), lo = Mathf.Min(e.maxMm, m.maxMm);
                if (hi > 0 && lo / hi < 0.8f)
                    foreach (var x in new[] { e, m })
                    {
                        x.issues.Add($"left/right differ: {e.maxMm:F1} vs {m.maxMm:F1} mm");
                        x.score = Mathf.Max(1, x.score - 1);
                    }
            }
        }
    }
}
