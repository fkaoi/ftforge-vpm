using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using FTForge.Bridge;
using UnityEngine;

namespace FTForge.Core
{
    static class TestCommands
    {
        /// <summary>
        /// Phase 0 check: sends the face mesh to Blender and back.
        /// copy(x) must equal x exactly, and split(x, Left) + split(x, Right) must equal x.
        /// Args: "prefabPath|shape"
        /// </summary>
        [BridgeCommand("testRoundtrip")]
        static string Roundtrip(string args)
        {
            var parts = args.Split('|');
            using var s = new AvatarSession(parts[0]);
            string shape = parts[1];
            var face = Analyzer.FindFaceMesh(s, s.Renderers.ToList());
            var job = new BlenderBridge.Job { renderer = face, sideCoord = new FaceModel(s, face).Rest.Select(p => p.x).ToArray(), sourceShapes = { shape } };
            job.ops.Add(new BlenderBridge.Op { op = "copy", source = shape, output = "copy" });
            job.ops.Add(new BlenderBridge.Op { op = "split", source = shape, side = "Left", falloff = 0.01f, output = "L" });
            job.ops.Add(new BlenderBridge.Op { op = "split", source = shape, side = "Right", falloff = 0.01f, output = "R" });
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var outp = BlenderBridge.Run(job, Path.Combine(Commands.OutputDir(s.Prefab.name), "work", "roundtrip"));
            var src = BlenderBridge.ShapeDelta(face.sharedMesh, shape);

            float copyErr = 0, sumErr = 0, maxSrc = 0;
            int movedL = 0, movedR = 0;
            for (int i = 0; i < src.Length; i++)
            {
                copyErr = Mathf.Max(copyErr, (outp["copy"][i] - src[i]).magnitude);
                sumErr = Mathf.Max(sumErr, (outp["L"][i] + outp["R"][i] - src[i]).magnitude);
                maxSrc = Mathf.Max(maxSrc, src[i].magnitude);
                if (outp["L"][i].sqrMagnitude > 1e-12f) movedL++;
                if (outp["R"][i].sqrMagnitude > 1e-12f) movedR++;
            }
            var sb = new StringBuilder();
            sb.AppendLine($"mesh={face.name} unityVerts={face.sharedMesh.vertexCount} shape={shape} blender={sw.ElapsedMilliseconds}ms");
            sb.AppendLine($"max |src|={maxSrc:E3}  copy err={copyErr:E3}  (L+R)-src err={sumErr:E3}");
            sb.AppendLine($"moved verts: L={movedL} R={movedR}");
            sb.AppendLine(copyErr <= maxSrc * 1e-4f + 1e-7f && sumErr <= maxSrc * 1e-4f + 1e-7f ? "PASS" : "FAIL");
            return sb.ToString();
        }

        /// <summary>Profile overrides take effect, survive a run, and approvals of unchanged results are kept.</summary>
        [BridgeCommand("testOverrides")]
        static string Overrides(string prefabPath)
        {
            var prefab = UnityEditor.AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            var profile = ProfileStore.LoadOrCreate(prefab);
            string backup = JsonUtility.ToJson(profile);
            var sb = new StringBuilder();
            try
            {
                var tongue = profile.GetOrAdd("TongueOut"); tongue.mode = FTForgeProfile.OverrideMode.Disable;
                var cheek = profile.GetOrAdd("CheekPuffLeft"); cheek.mode = FTForgeProfile.OverrideMode.UseRecipe; cheek.value = "Option_cheek_puku-_L + mouth_puku-_L";
                var jaw = profile.GetOrAdd("JawOpen"); jaw.multiplier = 0.8f;
                var eye = profile.GetOrAdd("EyeClosedLeft"); eye.approved = true;
                Pipeline.Run(prefabPath);

                using var s = new AvatarSession(Pipeline.WorkFolder + "/" + Synthesizer.Sanitize(prefab.name) + "/" + Synthesizer.Sanitize(prefab.name) + "_FTForge.prefab");
                var set = s.Descriptor.faceTrackingBlendshapesSetList.First(x => x.setName == Adapters.VrcFaceTrackingAdapter.SetName);
                int Idx(string k) => Adapters.VrcFaceTrackingAdapter.KeyNames.ToList().IndexOf(k);
                void Check(string what, bool ok) => sb.AppendLine($"{(ok ? "PASS" : "FAIL")} {what}");
                Check($"TongueOut disabled (mapped='{set.faceTrackingBlendshapeNames[Idx("TongueOut")]}')", set.faceTrackingBlendshapeNames[Idx("TongueOut")] == "");
                Check($"CheekPuffLeft uses generated shape (mapped='{set.faceTrackingBlendshapeNames[Idx("CheekPuffLeft")]}', recipe='{profile.Get("CheekPuffLeft").recipe}')",
                    set.faceTrackingBlendshapeNames[Idx("CheekPuffLeft")] == "CheekPuffLeft" && profile.Get("CheekPuffLeft").recipe.StartsWith("Option_cheek_puku-_L + mouth_puku-_L"));
                Check($"JawOpen multiplier 0.8 (got {set.faceTrackingBlendshapeMultipliers[Idx("JawOpen")]})", Mathf.Approximately(set.faceTrackingBlendshapeMultipliers[Idx("JawOpen")], 0.8f));
                Check("EyeClosedLeft approval kept (result unchanged)", profile.Get("EyeClosedLeft").approved);
                var json = System.IO.File.ReadAllText(System.IO.Path.Combine(Commands.OutputDir(prefab.name), "analysis.json"));
                int at = json.IndexOf("\"key\": \"CheekPuffLeft\"");
                sb.AppendLine("analysis: " + json.Substring(at, Mathf.Min(700, json.Length - at)).Replace("\n", " "));
                Check("override fields untouched by the run", profile.Get("CheekPuffLeft").mode == FTForgeProfile.OverrideMode.UseRecipe && profile.Get("TongueOut").mode == FTForgeProfile.OverrideMode.Disable);
            }
            finally
            {
                JsonUtility.FromJsonOverwrite(backup, profile);
                UnityEditor.EditorUtility.SetDirty(profile);
                UnityEditor.AssetDatabase.SaveAssetIfDirty(profile);
                Pipeline.Run(prefabPath); // restore the normal outputs
            }
            return sb.ToString();
        }

        /// <summary>Parser cases: operators need spaces, names may contain '-', quoting, nesting, scale.</summary>
        [BridgeCommand("testRecipeParser")]
        static string RecipeParser(string _)
        {
            var sb = new StringBuilder();
            void Case(string text, string expectShapes)
            {
                try
                {
                    var n = Recipe.Parse(text);
                    string got = string.Join(",", n.Shapes());
                    sb.AppendLine($"{(got == expectShapes ? "PASS" : "FAIL")} {text} -> {got}");
                }
                catch (System.Exception e) { sb.AppendLine($"{(expectShapes == "ERROR" ? "PASS" : "FAIL")} {text} -> {e.Message}"); }
            }
            Case("a + b", "a,b");
            Case("Option_cheek_puku-_L + mouth_puku-_L", "Option_cheek_puku-_L,mouth_puku-_L");
            Case("0.5*a - 0.25*b", "a,b");
            Case("-1*@JawOpen", "@JawOpen");
            Case("split(mask(@v_ih, upperLip), Left)", "@v_ih");
            Case("split(a + b, Right, 0.02)", "a,b");
            Case("mask(\"eye_><\", eyeL, $f)", "eye_><");
            Case("(a + b) - c", "a,b,c");
            Case("split(a)", "ERROR");
            Case("a +b", "ERROR");
            return sb.ToString();
        }

        /// <summary>Skin-matrix deltas (used for fast evaluation) must match baked, skinned deltas.</summary>
        [BridgeCommand("testSkin")]
        static string Skin(string args)
        {
            var parts = args.Split('|');
            using var s = new AvatarSession(parts[0]);
            var face = Analyzer.FindFaceMesh(s, s.Renderers.ToList());
            var model = new FaceModel(s, face);
            int idx = face.sharedMesh.GetBlendShapeIndex(parts[1]);
            var fast = model.ToAvatarDelta(model.ShapeDelta(parts[1]));
            var baked = MeshSampler.WorldDelta(face, idx);
            float err = 0, max = 0;
            for (int i = 0; i < fast.Length; i++)
            {
                var b = s.Root.transform.InverseTransformDirection(baked[i]);
                err = Mathf.Max(err, (fast[i] - b).magnitude);
                max = Mathf.Max(max, b.magnitude);
            }
            return $"{parts[1]}: max baked {max * 1000:F2} mm, max diff {err * 1000:F4} mm, scale {face.transform.lossyScale} -> {(err < max * 0.01f ? "PASS" : "FAIL")}";
        }

        /// <summary>Phase 3 probe: open boundary loops near the mouth and bones driving the lips.</summary>
        [BridgeCommand("probeMouth")]
        static string ProbeMouth(string prefabPath)
        {
            using var s = new AvatarSession(prefabPath);
            var face = Analyzer.FindFaceMesh(s, s.Renderers.ToList());
            var m = new FaceModel(s, face);
            var topo = new Topology(face.sharedMesh, new[] { m.ShapeDelta("vrc.v_aa") });
            var sb = new StringBuilder();
            sb.AppendLine($"verts={m.VertexCount} welded={topo.WeldedCount} loops={topo.BoundaryLoops.Count} IOD={m.Iod * 1000:F1}mm mouthY={m.MouthLineY * 1000:F1}mm halfW={m.MouthHalfWidth * 1000:F1}mm eyeY={m.EyeL.y * 1000:F1}mm");
            Vector3 mouth = new Vector3(0, m.MouthLineY, 0);
            foreach (var loop in topo.BoundaryLoops.OrderBy(l => -l.Count).Take(25))
            {
                var pts = loop.Select(w => m.Rest[topo.Members[w][0]]).ToList();
                var c = pts.Aggregate(Vector3.zero, (a, b) => a + b) / pts.Count;
                float w = pts.Max(p => p.x) - pts.Min(p => p.x), h = pts.Max(p => p.y) - pts.Min(p => p.y);
                sb.AppendLine($"  loop n={loop.Count} centre=({c.x * 1000:F1},{c.y * 1000:F1},{c.z * 1000:F1})mm size={w * 1000:F1}x{h * 1000:F1}mm distToMouth={(new Vector2(c.x, c.y) - new Vector2(0, m.MouthLineY)).magnitude / m.Iod:F2}IOD");
            }
            // bones weighted on vertices that move down in the aa viseme
            var aa = m.ToAvatarDelta(m.ShapeDelta("vrc.v_aa"));
            var ih = m.ToAvatarDelta(m.ShapeDelta("vrc.v_ih"));
            foreach (var loop in topo.BoundaryLoops.Where(l => { var c = l.Select(w => m.Rest[topo.Members[w][0]]).Aggregate(Vector3.zero, (a, b) => a + b) / l.Count; return Mathf.Abs(c.x) < 0.1f * m.Iod && Mathf.Abs(c.y - m.MouthLineY) < 0.3f * m.Iod; }))
            {
                var vs = loop.Select(w => topo.Members[w][0]).ToList();
                float upY = vs.Where(i => aa[i].y > 0).Select(i => aa[i].y).DefaultIfEmpty(0).Max();
                float dnY = vs.Where(i => aa[i].y < 0).Select(i => aa[i].y).DefaultIfEmpty(0).Min();
                var mats = new HashSet<int>();
                for (int sm = 0; sm < face.sharedMesh.subMeshCount; sm++) { var t = face.sharedMesh.GetTriangles(sm); var set = new HashSet<int>(t); if (vs.Any(set.Contains)) mats.Add(sm); }
                sb.AppendLine($"  mouth loop n={loop.Count} z={vs.Average(i => m.Rest[i].z) * 1000:F1} y=[{vs.Min(i => m.Rest[i].y) * 1000:F1},{vs.Max(i => m.Rest[i].y) * 1000:F1}] aa up {upY * 1000:F1} down {dnY * 1000:F1} mm, ih mean {vs.Average(i => ih[i].magnitude) * 1000:F1} mm, submeshes [{string.Join(",", mats.Select(x => face.sharedMaterials[x].name))}]");
            }
            var bw = face.sharedMesh.boneWeights; var bones = face.bones;
            var tally = new Dictionary<string, float>();
            for (int i = 0; i < aa.Length; i++)
                if (aa[i].y < -0.001f)
                {
                    var w = bw[i];
                    void Add(int b, float x) { if (x > 0) { string n = bones[b] != null ? bones[b].name : "?"; tally[n] = (tally.TryGetValue(n, out var t) ? t : 0) + x; } }
                    Add(w.boneIndex0, w.weight0); Add(w.boneIndex1, w.weight1); Add(w.boneIndex2, w.weight2); Add(w.boneIndex3, w.weight3);
                }
            sb.AppendLine("bones on lower lip/jaw: " + string.Join(", ", tally.OrderByDescending(x => x.Value).Take(6).Select(x => $"{x.Key}={x.Value:F0}")));
            sb.AppendLine("all bones containing jaw/ago/chin: " + string.Join(", ", s.Root.GetComponentsInChildren<Transform>(true).Where(t => System.Text.RegularExpressions.Regex.IsMatch(t.name, "jaw|ago|chin|顎", System.Text.RegularExpressions.RegexOptions.IgnoreCase)).Select(t => t.name)));
            return sb.ToString();
        }

        /// <summary>Debug image: mouth-area boundary loops drawn over the front view (and with aa applied).</summary>
        [BridgeCommand("drawMouthLoops")]
        static string DrawMouthLoops(string prefabPath)
        {
            using var s = new AvatarSession(prefabPath);
            var face = Analyzer.FindFaceMesh(s, s.Renderers.ToList());
            var m = new FaceModel(s, face);
            var topo = new Topology(face.sharedMesh, new[] { m.ShapeDelta("vrc.v_aa") });
            var loops = topo.BoundaryLoops.Where(l => { var c = l.Select(w => m.Rest[topo.Members[w][0]]).Aggregate(Vector3.zero, (a, b) => a + b) / l.Count; return Mathf.Abs(c.x) < 0.1f * m.Iod && Mathf.Abs(c.y - m.MouthLineY) < 0.3f * m.Iod; }).ToList();
            Color32[] colours = { new Color32(255, 0, 0, 255), new Color32(0, 120, 255, 255), new Color32(0, 200, 0, 255) };
            string dir = Commands.OutputDir(s.Prefab.name);
            using var cap = new Capture(s, face);
            int aa = face.sharedMesh.GetBlendShapeIndex("vrc.v_aa");
            var files = new List<string>();
            foreach (float w in new[] { 0f, 100f })
            {
                face.SetBlendShapeWeight(aa, w);
                var img = cap.Render(0f);
                var world = MeshSampler.BakeWorld(face);
                for (int li = 0; li < loops.Count; li++)
                    foreach (int wid in loops[li])
                    {
                        var vp = cap.Camera.WorldToViewportPoint(world[topo.Members[wid][0]]);
                        int x = (int)(vp.x * Capture.Size), y = (int)(vp.y * Capture.Size);
                        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++)
                            if (x + dx >= 0 && x + dx < Capture.Size && y + dy >= 0 && y + dy < Capture.Size) img.SetPixel(x + dx, y + dy, colours[li % 3]);
                    }
                img.Apply();
                string f = System.IO.Path.Combine(dir, $"mouthloops_{w:F0}.png");
                System.IO.File.WriteAllBytes(f, img.EncodeToPNG());
                files.Add(f);
            }
            face.SetBlendShapeWeight(aa, 0);
            return string.Join(" ", files) + $" | loops:{string.Join(", ", loops.Select((l, i) => $"{(i % 3 == 0 ? "red" : i % 3 == 1 ? "blue" : "green")} n={l.Count}"))}";
        }

        /// <summary>Distance from each mouth-area boundary vertex to the nearest boundary vertex of another loop.</summary>
        [BridgeCommand("probeSeams")]
        static string ProbeSeams(string prefabPath)
        {
            using var s = new AvatarSession(prefabPath);
            var face = Analyzer.FindFaceMesh(s, s.Renderers.ToList());
            var m = new FaceModel(s, face);
            var topo = new Topology(face.sharedMesh);
            var near = topo.BoundaryLoops.Select((l, i) => (l, i)).Where(x => x.l.Any(w => { var p = m.Rest[topo.Members[w][0]]; return Mathf.Abs(p.x) < m.MouthHalfWidth * 1.5f && Mathf.Abs(p.y - m.MouthLineY) < 0.4f * m.Iod && p.z > 0; })).ToList();
            var sb = new StringBuilder();
            foreach (var (l, i) in near)
            {
                var d = new List<float>();
                foreach (int w in l)
                {
                    var p = m.Rest[topo.Members[w][0]];
                    float best = float.MaxValue;
                    foreach (var (l2, j) in near) if (j != i) foreach (int w2 in l2) best = Mathf.Min(best, Vector3.Distance(p, m.Rest[topo.Members[w2][0]]));
                    d.Add(best * 1000);
                }
                d.Sort();
                var c = l.Select(w => m.Rest[topo.Members[w][0]]).Aggregate(Vector3.zero, (a, b) => a + b) / l.Count;
                sb.AppendLine($"loop {i} n={l.Count} centre y={c.y * 1000:F1} z={c.z * 1000:F1}: nearest-other mm min={d[0]:F2} p25={d[d.Count / 4]:F2} p50={d[d.Count / 2]:F2} p75={d[d.Count * 3 / 4]:F2} max={d[d.Count - 1]:F2}");
            }
            return sb.ToString();
        }

        /// <summary>Stage D probe: seed/visibility counts and how much the frontmost mouth skin moves.</summary>
        [BridgeCommand("probeStageD")]
        static string ProbeStageD(string args)
        {
            var parts = args.Split('|');
            using var s = new AvatarSession(parts[0]);
            var face = Analyzer.FindFaceMesh(s, s.Renderers.ToList());
            var m = new FaceModel(s, face);
            var sb = new StringBuilder();
            var vis = m.Visible;
            int nearMouth = 0, visNear = 0;
            for (int i = 0; i < m.VertexCount; i++)
                if (Mathf.Abs(m.Rest[i].x) < m.MouthHalfWidth * 1.2f && Mathf.Abs(m.Rest[i].y - m.MouthLineY) < 0.15f * m.Iod && m.Rest[i].z > 0) { nearMouth++; if (vis[i] > 0) visNear++; }
            sb.AppendLine($"near mouth: {nearMouth} verts, visible {visNear}; seeds: {m.SeedNote}");
            foreach (var name in FaceModel.SeedNames)
            {
                var w = m.Seeds(name);
                var ids = Enumerable.Range(0, m.VertexCount).Where(i => w[i] > 0).ToList();
                sb.AppendLine($"  {name}: {ids.Count} verts, z range [{(ids.Count > 0 ? ids.Min(i => m.Rest[i].z) * 1000 : 0):F1},{(ids.Count > 0 ? ids.Max(i => m.Rest[i].z) * 1000 : 0):F1}] mm");
            }
            // read a generated shape from the preview mesh and report motion of visible vs hidden vertices near the mouth
            var prev = UnityEditor.AssetDatabase.LoadAssetAtPath<Mesh>(Pipeline.WorkFolder + "/Chocolat/Body_FTForge.asset");
            if (prev != null && parts.Length > 1 && prev.GetBlendShapeIndex(parts[1]) >= 0)
            {
                var d = m.ToAvatarDelta(BlenderBridge.ShapeDelta(prev, parts[1]));
                float visMax = 0, hidMax = 0; int visMoved = 0, hidMoved = 0;
                for (int i = 0; i < m.VertexCount; i++)
                {
                    float x = d[i].magnitude; if (x < 1e-4f) continue;
                    if (vis[i] > 0) { visMoved++; visMax = Mathf.Max(visMax, x); } else { hidMoved++; hidMax = Mathf.Max(hidMax, x); }
                }
                sb.AppendLine($"{parts[1]}: visible moved {visMoved} (max {visMax * 1000:F2} mm), hidden moved {hidMoved} (max {hidMax * 1000:F2} mm)");
            }
            return sb.ToString();
        }

        /// <summary>Which vertices lie under newly dark pixels of a generated key (front view)?</summary>
        [BridgeCommand("probeDark")]
        static string ProbeDark(string args)
        {
            var parts = args.Split('|');
            using var s = new AvatarSession(parts[0]);
            var face = Analyzer.FindFaceMesh(s, s.Renderers.ToList());
            var prev = UnityEditor.AssetDatabase.LoadAssetAtPath<Mesh>(Pipeline.WorkFolder + "/Chocolat/Body_FTForge.asset");
            face.sharedMesh = prev;
            var m = new FaceModel(s, face);
            int idx = prev.GetBlendShapeIndex(parts[1]);
            using var cap = new Capture(s, face);
            var a = cap.Render(0f); face.SetBlendShapeWeight(idx, 100); var b = cap.Render(0f);
            var after = MeshSampler.BakeWorld(face); face.SetBlendShapeWeight(idx, 0);
            var pa = a.GetPixels32(); var pb = b.GetPixels32();
            int minX = 9999, minY = 9999, maxX = -1, maxY = -1, n = 0;
            for (int i = 0; i < pa.Length; i++)
            {
                int la = pa[i].r + pa[i].g + pa[i].b, lb = pb[i].r + pb[i].g + pb[i].b;
                if (la - lb > 150) { int x = i % Capture.Size, y = i / Capture.Size; minX = Mathf.Min(minX, x); maxX = Mathf.Max(maxX, x); minY = Mathf.Min(minY, y); maxY = Mathf.Max(maxY, y); n++; }
            }
            var sb = new StringBuilder($"dark px {n} bbox x[{minX},{maxX}] y[{minY},{maxY}]\n");
            if (n == 0) return sb.ToString();
            var d = m.ToAvatarDelta(BlenderBridge.ShapeDelta(prev, parts[1]));
            var sub = new int[m.VertexCount];
            for (int sm = 0; sm < prev.subMeshCount; sm++) foreach (int t in prev.GetTriangles(sm)) sub[t] = sm;
            var rows = new List<string>();
            for (int i = 0; i < m.VertexCount; i++)
            {
                var vp = cap.Camera.WorldToViewportPoint(after[i]);
                float x = vp.x * Capture.Size, y = vp.y * Capture.Size;
                if (x < minX - 3 || x > maxX + 3 || y < minY - 3 || y > maxY + 3) continue;
                rows.Add($"v{i} sub={face.sharedMaterials[sub[i]].name} rest=({m.Rest[i].x * 1000:F1},{m.Rest[i].y * 1000:F1},{m.Rest[i].z * 1000:F1}) d=({d[i].x * 1000:F2},{d[i].y * 1000:F2},{d[i].z * 1000:F2}) vis={m.Visible[i]} strict={m.VisibleStrict[i]}");
            }
            sb.AppendLine($"{rows.Count} vertices project into the box");
            // frontmost (closest to the camera) vertices inside the dark box after deformation
            var camPos = cap.Camera.transform.position;
            var inBox = new List<int>();
            for (int i = 0; i < m.VertexCount; i++)
            {
                var vp = cap.Camera.WorldToViewportPoint(after[i]);
                float x = vp.x * Capture.Size, y = vp.y * Capture.Size;
                if (x >= minX && x <= maxX && y >= minY && y <= maxY) inBox.Add(i);
            }
            foreach (int i in inBox.OrderBy(i => Vector3.Distance(after[i], camPos)).Take(12))
                sb.AppendLine($"  front v{i} sub={face.sharedMaterials[sub[i]].name} rest=({m.Rest[i].x * 1000:F1},{m.Rest[i].y * 1000:F1},{m.Rest[i].z * 1000:F1}) d=({d[i].x * 1000:F2},{d[i].y * 1000:F2},{d[i].z * 1000:F2}) vis={m.Visible[i]} strict={m.VisibleStrict[i]} camDist={Vector3.Distance(after[i], camPos) * 1000:F1}");
            // and what was frontmost there before deformation
            var before = MeshSampler.BakeWorld(face);
            var inBoxBefore = new List<int>();
            for (int i = 0; i < m.VertexCount; i++)
            {
                var vp = cap.Camera.WorldToViewportPoint(before[i]);
                float x = vp.x * Capture.Size, y = vp.y * Capture.Size;
                if (x >= minX && x <= maxX && y >= minY && y <= maxY) inBoxBefore.Add(i);
            }
            foreach (int i in inBoxBefore.OrderBy(i => Vector3.Distance(before[i], camPos)).Take(6))
                sb.AppendLine($"  before v{i} sub={face.sharedMaterials[sub[i]].name} rest=({m.Rest[i].x * 1000:F1},{m.Rest[i].y * 1000:F1},{m.Rest[i].z * 1000:F1}) d=({d[i].x * 1000:F2},{d[i].y * 1000:F2},{d[i].z * 1000:F2}) camDist={Vector3.Distance(before[i], camPos) * 1000:F1}");
            return sb.ToString();
        }

    }
}
