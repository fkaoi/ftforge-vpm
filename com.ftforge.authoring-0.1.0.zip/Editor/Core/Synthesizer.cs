using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FTForge.Core
{
    /// <summary>A generated blendshape: mesh-space position deltas in the Unity mesh's vertex order.</summary>
    public sealed class GeneratedShape
    {
        public string key;          // UE key it is generated for
        public string name;         // blendshape name to add
        public string meshPath;
        public string rule;         // winning recipe
        public float splitFalloff;  // winning falloff (metres)
        public Vector3[] delta;
        public KeyEvaluation eval;  // vertex evaluation of the winner
        public Vector3[] reference; // avatar-space delta of the winner without split/mask (crease check)
        public List<string> tried = new List<string>(); // "score quality recipe @falloff" per candidate
    }

    /// <summary>
    /// Stages B and C. Every candidate recipe is evaluated at every split falloff on vertex data;
    /// the best (score, then quality) is kept. Stage D (new deformations) goes through Blender in Phase 3.
    /// </summary>
    public static class Synthesizer
    {
        // Earlier candidates (rule order, default falloff) win unless a later one is clearly better.
        const float TieMargin = 0.05f;

        public static List<GeneratedShape> Run(AvatarSession s, AnalysisReport report, FaceModel face, FTForgeProfile profile, Func<string, string> resolve, string workRoot = null)
        {
            var result = new List<GeneratedShape>();
            var ev = new Evaluator(face);
            float baseFalloff = profile != null && profile.splitFalloff > 0 ? profile.splitFalloff : 0.01f;
            float[] multiples = profile != null && profile.falloffCandidates != null && profile.falloffCandidates.Length > 0 ? profile.falloffCandidates : new[] { 1f };
            float maskFalloff = profile != null && profile.maskFalloff > 0 ? profile.maskFalloff : 0.08f;
            var precomputed = RunStageD(s, report, face, workRoot);

            var keys = report.keys.Where(k => k.status == nameof(KeyStatus.Synthesizable)).ToList();
            var byKey = keys.ToDictionary(k => k.key);
            var options = keys.ToDictionary(k => k.key, k => Options(k, profile, face, ev, resolve, precomputed, baseFalloff, multiples, maskFalloff));
            var chosen = new Dictionary<string, Option>();

            // Left/right pairs are chosen together: the same recipe (mirrored) and falloff on both sides.
            foreach (var k in keys)
            {
                if (chosen.ContainsKey(k.key)) continue;
                string mirror = Rules.Mirror(k.key);
                if (Rules.SideOf(k.key) == "Left" && mirror != null && byKey.ContainsKey(mirror))
                {
                    Option bestL = null, bestR = null;
                    foreach (var l in options[k.key].Where(o => o.eval != null))
                    {
                        var r = options[mirror].FirstOrDefault(o => o.eval != null && o.text == MirrorText(l.text) && Mathf.Approximately(o.falloff, l.falloff));
                        if (r == null) continue;
                        if (bestL == null || Better(l.eval.score + r.eval.score, l.eval.quality + r.eval.quality, bestL.eval.score + bestR.eval.score, bestL.eval.quality + bestR.eval.quality))
                        { bestL = l; bestR = r; }
                    }
                    if (bestL != null) { chosen[k.key] = bestL; chosen[mirror] = bestR; continue; }
                }
                if (Rules.SideOf(k.key) == "Right" && mirror != null && byKey.ContainsKey(mirror)) continue; // handled with its left half
                var best = options[k.key].Where(o => o.eval != null).Aggregate((Option)null, (b, o) => b == null || Better(o.eval.score, o.eval.quality, b.eval.score, b.eval.quality) ? o : b);
                if (best != null) chosen[k.key] = best;
            }
            // Right halves whose left half had no matching recipe are chosen on their own.
            foreach (var k in keys.Where(k => !chosen.ContainsKey(k.key)))
            {
                var best = options[k.key].Where(o => o.eval != null).Aggregate((Option)null, (b, o) => b == null || Better(o.eval.score, o.eval.quality, b.eval.score, b.eval.quality) ? o : b);
                if (best != null) chosen[k.key] = best;
            }

            foreach (var k in keys)
            {
                var tried = options[k.key].Select(o => o.log).ToList();
                if (!chosen.TryGetValue(k.key, out var c)) { k.status = nameof(KeyStatus.Unavailable); k.note = "all candidates failed: " + string.Join(" | ", tried); continue; }
                c.eval.candidatesTried = tried.Count;
                k.rule = c.text + (c.text.Contains("split(") ? $" @{c.falloff * 1000:F0}mm" : "");
                result.Add(new GeneratedShape { key = k.key, name = k.shape, meshPath = k.meshPath, rule = c.text, splitFalloff = c.falloff, delta = c.delta, eval = c.eval, reference = c.reference, tried = tried });
            }
            report.Count();
            return result;
        }


        sealed class Option
        {
            public string text, log;
            public float falloff;
            public Vector3[] delta, reference;
            public KeyEvaluation eval; // null when the candidate failed
        }

        // Later candidates must be clearly better to replace an earlier one (rule order is priority).
        static bool Better(int score, float quality, int bestScore, float bestQuality) =>
            score > bestScore || (score == bestScore && quality > bestQuality + TieMargin);

        static readonly System.Text.RegularExpressions.Regex SideArg = new System.Text.RegularExpressions.Regex(@",\s*(Left|Right)\b");
        static string MirrorText(string text) => SideArg.Replace(text, m => m.Value.Replace(m.Groups[1].Value, m.Groups[1].Value == "Left" ? "Right" : "Left"));

        /// <summary>Every candidate recipe of a key at every applicable falloff, evaluated on vertex data.</summary>
        static List<Option> Options(KeyResult k, FTForgeProfile profile, FaceModel face, Evaluator ev, Func<string, string> resolve,
            Dictionary<string, Vector3[]> precomputed, float baseFalloff, float[] multiples, float maskFalloff)
        {
            var list = new List<Option>();
            var entry = profile?.Get(k.key);
            float keyFalloff = entry != null && entry.splitFalloff > 0 ? entry.splitFalloff : baseFalloff;
            // A falloff set for this key by hand is used as is; otherwise try the multiples, default first.
            var falloffs = entry != null && entry.splitFalloff > 0 ? new[] { keyFalloff } : multiples.OrderBy(m => Mathf.Abs(m - 1f)).Select(m => m * keyFalloff).Distinct().ToArray();
            foreach (string text in k.candidates)
            {
                Recipe.Node node;
                try { node = Recipe.Parse(text); }
                catch (FormatException e) { list.Add(new Option { text = text, log = $"parse error: {e.Message}" }); continue; }
                bool usesSplit = text.Contains("split(");
                Vector3[] reference;
                try { reference = face.ToAvatarDelta(node.Eval(new Recipe.Context { face = face, resolve = resolve, noMasks = true, precomputed = precomputed })); }
                catch (Exception e) { list.Add(new Option { text = text, log = $"unavailable: {text}: {e.Message}" }); continue; }
                foreach (float f in usesSplit ? falloffs : new[] { keyFalloff })
                {
                    var ctx = new Recipe.Context { face = face, resolve = resolve, defaultSplitFalloff = f, defaultMaskFalloff = maskFalloff, precomputed = precomputed };
                    Vector3[] delta;
                    try { delta = node.Eval(ctx); }
                    catch (Exception e) { list.Add(new Option { text = text, falloff = f, log = $"error: {text}: {e.Message}" }); continue; }
                    var e2 = ev.EvaluateDelta(k.key, face.ToAvatarDelta(delta), reference);
                    Evaluator.Score(e2);
                    list.Add(new Option
                    {
                        text = text, falloff = f, delta = delta, reference = reference, eval = e2,
                        log = $"{e2.score} q={e2.quality:F2} {text}{(usesSplit ? $" @{f * 1000:F0}mm" : "")}{(e2.issues.Count > 0 ? " — " + string.Join("; ", e2.issues) : "")}",
                    });
                }
            }
            return list;
        }

        /// <summary>
        /// Runs every deform(...) used by any candidate in one Blender job. Seeds and displacements are prepared
        /// here in avatar space and converted to mesh space; Blender does the surface-distance falloff.
        /// </summary>
        static Dictionary<string, Vector3[]> RunStageD(AvatarSession s, AnalysisReport report, FaceModel face, string workRoot)
        {
            var result = new Dictionary<string, Vector3[]>();
            var nodes = new Dictionary<string, Recipe.DeformNode>();
            foreach (var k in report.keys.Where(k => k.status == nameof(KeyStatus.Synthesizable)))
                foreach (var text in k.candidates)
                {
                    try { foreach (var n in Recipe.Parse(text).All().OfType<Recipe.DeformNode>()) nodes[n.Key] = n; }
                    catch (FormatException) { }
                }
            if (nodes.Count == 0 || workRoot == null) return result;

            var job = new BlenderBridge.Job { renderer = face.Renderer, sideCoord = face.Rest.Select(p => p.x).ToArray(), weld = face.Topo.Weld };
            var edges = new List<int>();
            for (int a = 0; a < face.Topo.WeldedCount; a++)
                foreach (int b in face.Topo.Neighbours[a]) if (a < b) { edges.Add(a); edges.Add(b); }
            job.edges = edges.ToArray();

            // Shared inputs for keeping hidden parts behind the skin.
            job.files["visible.f32"] = face.VisibleStrict;
            var proj = new float[face.VertexCount * 2];
            for (int i = 0; i < face.VertexCount; i++) { proj[i * 2] = face.Rest[i].x; proj[i * 2 + 1] = face.Rest[i].y; }
            job.files["proj.f32"] = proj;

            int idx = 0;
            var outputs = new Dictionary<string, string>();
            foreach (var n in nodes.Values)
            {
                float[] seeds;
                try { seeds = face.Seeds(n.seed); }
                catch (ArgumentException e) { Debug.LogWarning("[FTForge] " + e.Message); continue; }
                var seedIdx = Enumerable.Range(0, face.VertexCount).Where(i => seeds[i] > 0).ToList();
                if (seedIdx.Count == 0) continue;
                float cx = seedIdx.Average(i => face.Rest[i].x);
                float half = Mathf.Max(1e-5f, seedIdx.Max(i => Mathf.Abs(face.Rest[i].x - cx)));
                var disp = new float[face.VertexCount * 3];
                foreach (int i in seedIdx)
                {
                    var a = new Vector3(n.dx, n.dy, n.dz) * face.Iod;
                    float rx = face.Rest[i].x - cx;
                    a.x -= Mathf.Sign(rx) * n.toCentre * face.Iod * Mathf.Min(1f, Mathf.Abs(rx) / half);
                    var m = face.ToMeshDir(i, a) * seeds[i];
                    disp[i * 3] = m.x; disp[i * 3 + 1] = m.y; disp[i * 3 + 2] = m.z;
                }
                string name = "d" + idx++;
                job.files[name + "_seeds.f32"] = seeds;
                job.files[name + "_disp.f32"] = disp;
                job.ops.Add(new BlenderBridge.Op { op = "push", seeds = name + "_seeds.f32", disp = name + "_disp.f32", radius = n.radius * face.Iod / face.MeshScale(seedIdx), smooth = 3, metric = face.SeedMetric, visible = "visible.f32", proj = "proj.f32",
                    spatial = 0.035f * face.Iod / face.MeshScale(seedIdx), output = name });
                outputs[name] = n.Key;
            }
            if (job.ops.Count == 0) return result;
            var res = BlenderBridge.Run(job, System.IO.Path.Combine(workRoot, "stageD"));
            foreach (var kv in outputs) result[kv.Value] = res[kv.Key];
            Debug.Log($"[FTForge] stage D: {res.Count} deformation(s) in Blender; {face.SeedNote}");
            return result;
        }

        public static string Sanitize(string s) => string.Concat(s.Select(c => System.IO.Path.GetInvalidFileNameChars().Contains(c) || c == '/' ? '_' : c));
    }
}
