using System;
using System.Collections.Generic;
using System.Linq;
using FTForge.Adapters;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace FTForge.Core
{
    /// <summary>
    /// Builds <see cref="FTForgeShapeData"/> from generated shapes. Applying it is done by
    /// <see cref="ShapeApply"/> in com.ftforge.core (shared with the NDMF pass).
    /// </summary>
    public static class ShapeApplier
    {
        public static FTForgeShapeData Build(AvatarSession s, AnalysisReport analysis, List<GeneratedShape> generated)
        {
            var data = ScriptableObject.CreateInstance<FTForgeShapeData>();
            data.sourceAvatar = s.Prefab.name;
            data.generatorVersion = FTForgeInfo.Version;
            foreach (var group in generated.GroupBy(g => g.meshPath))
            {
                var r = s.FindRenderer(group.Key);
                var md = new FTForgeShapeData.MeshDeltas
                {
                    rendererPath = group.Key, meshName = r.sharedMesh.name, vertexCount = r.sharedMesh.vertexCount, baseHash = ShapeApply.BaseHash(r.sharedMesh),
                };
                foreach (var g in group)
                {
                    var normals = MeshWriter.NormalDelta(r.sharedMesh, g.delta);
                    var idx = Enumerable.Range(0, g.delta.Length).Where(i => g.delta[i].sqrMagnitude > 1e-16f || normals[i].sqrMagnitude > 1e-12f).ToArray();
                    md.shapes.Add(new FTForgeShapeData.Shape
                    {
                        name = g.name, indices = idx, positions = idx.Select(i => g.delta[i]).ToArray(), normals = idx.Select(i => normals[i]).ToArray(),
                    });
                }
                data.meshes.Add(md);
            }
            foreach (var k in analysis.keys.Where(k => k.status != nameof(KeyStatus.Unavailable) && !string.IsNullOrEmpty(k.shape)))
                data.mappings.Add(new FTForgeShapeData.Mapping { key = k.key, rendererPath = k.meshPath, shape = k.shape, multiplier = k.multiplier });
            return data;
        }

    }
}
