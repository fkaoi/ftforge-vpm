using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace FTForge.Core
{
    [CustomEditor(typeof(FTForgeProfile))]
    public sealed class ProfileEditor : Editor
    {
        enum Filter { All, NeedsReview, NotApproved, Overridden, Unassigned }
        static Filter _filter = Filter.NeedsReview;
        static string _search = "";
        Vector2 _scroll;

        public override void OnInspectorGUI()
        {
            var p = (FTForgeProfile)target;
            serializedObject.Update();

            EditorGUILayout.PropertyField(serializedObject.FindProperty("avatarPrefab"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("faceMeshPath"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("splitFalloff"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("maskFalloff"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("falloffCandidates"), true);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("extraAliases"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("extraRecipes"));

            EditorGUILayout.Space();
            if (!string.IsNullOrEmpty(p.lastRun))
                EditorGUILayout.HelpBox($"Last run {p.lastRun}\n{p.lastSummary}", MessageType.None);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(p.avatarPrefab == null))
                    if (GUILayout.Button("Run"))
                    {
                        serializedObject.ApplyModifiedProperties();
                        Debug.Log("[FTForge] " + Pipeline.Run(AssetDatabase.GetAssetPath(p.avatarPrefab)));
                        GUIUtility.ExitGUI();
                    }
                if (GUILayout.Button("Open Report") && p.avatarPrefab != null)
                {
                    string path = Pipeline.ReportPath(p.avatarPrefab.name);
                    if (File.Exists(path)) Application.OpenURL("file:///" + path.Replace('\\', '/'));
                }
                using (new EditorGUI.DisabledScope(p.avatarPrefab == null))
                    if (GUILayout.Button("Export Package"))
                    {
                        string result = Exporter.Export(p.avatarPrefab);
                        Debug.Log("[FTForge] " + result);
                        EditorUtility.RevealInFinder(Path.Combine(Commands.OutputDir(p.avatarPrefab.name), $"FTForge_{Synthesizer.Sanitize(p.avatarPrefab.name)}.unitypackage"));
                        GUIUtility.ExitGUI();
                    }
                if (GUILayout.Button("Approve all scored 5"))
                {
                    Undo.RecordObject(p, "Approve");
                    foreach (var k in p.keys.Where(k => k.score == 5)) k.approved = true;
                    EditorUtility.SetDirty(p);
                }
            }

            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope())
            {
                _filter = (Filter)EditorGUILayout.EnumPopup(_filter, GUILayout.Width(110));
                _search = EditorGUILayout.TextField(_search);
            }

            var keys = serializedObject.FindProperty("keys");
            int shown = 0;
            _scroll = EditorGUILayout.BeginScrollView(_scroll, GUILayout.MinHeight(200), GUILayout.MaxHeight(700));
            for (int i = 0; i < keys.arraySize; i++)
            {
                var entry = p.keys[i];
                if (!Visible(entry)) continue;
                shown++;
                var el = keys.GetArrayElementAtIndex(i);
                DrawEntry(el, entry);
            }
            EditorGUILayout.EndScrollView();
            if (shown == 0) EditorGUILayout.LabelField("No keys match the filter.");
            serializedObject.ApplyModifiedProperties();
        }

        static bool Visible(FTForgeProfile.KeyEntry e)
        {
            if (!string.IsNullOrEmpty(_search) && e.key.IndexOf(_search, System.StringComparison.OrdinalIgnoreCase) < 0) return false;
            bool assigned = !e.status.StartsWith("Unavailable") && !string.IsNullOrEmpty(e.status);
            return _filter switch
            {
                Filter.NeedsReview => assigned && (e.score <= 3 || !e.approved),
                Filter.NotApproved => assigned && !e.approved,
                Filter.Overridden => e.mode != FTForgeProfile.OverrideMode.Auto,
                Filter.Unassigned => !assigned,
                _ => true,
            };
        }

        static void DrawEntry(SerializedProperty el, FTForgeProfile.KeyEntry e)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    var style = new GUIStyle(EditorStyles.boldLabel);
                    if (e.score > 0) style.normal.textColor = e.score >= 4 ? new Color(0.2f, 0.65f, 0.2f) : e.score == 3 ? new Color(0.8f, 0.55f, 0f) : new Color(0.85f, 0.2f, 0.2f);
                    el.isExpanded = EditorGUILayout.Foldout(el.isExpanded, $"{e.key}   {(e.score > 0 ? e.score.ToString() : "-")}", true, new GUIStyle(EditorStyles.foldout) { fontStyle = FontStyle.Bold, normal = { textColor = style.normal.textColor } });
                    GUILayout.FlexibleSpace();
                    EditorGUILayout.PropertyField(el.FindPropertyRelative("approved"), GUIContent.none, GUILayout.Width(16));
                    GUILayout.Label("approved", GUILayout.Width(60));
                }
                string result = string.IsNullOrEmpty(e.recipe) ? e.shape : e.recipe;
                EditorGUILayout.LabelField($"{e.status}  {result}", EditorStyles.miniLabel);
                if (!el.isExpanded) return;

                EditorGUILayout.PropertyField(el.FindPropertyRelative("mode"));
                var mode = (FTForgeProfile.OverrideMode)el.FindPropertyRelative("mode").enumValueIndex;
                if (mode == FTForgeProfile.OverrideMode.UseShape || mode == FTForgeProfile.OverrideMode.UseRecipe)
                    EditorGUILayout.PropertyField(el.FindPropertyRelative("value"), new GUIContent(mode == FTForgeProfile.OverrideMode.UseShape ? "Blendshape" : "Recipe"));
                EditorGUILayout.PropertyField(el.FindPropertyRelative("multiplier"));
                EditorGUILayout.PropertyField(el.FindPropertyRelative("splitFalloff"));
                EditorGUILayout.PropertyField(el.FindPropertyRelative("memo"));
                if (!string.IsNullOrEmpty(e.issues)) EditorGUILayout.HelpBox(e.issues, MessageType.None);
                if (e.candidatesTried > 1) EditorGUILayout.LabelField($"{e.candidatesTried} candidates tried (see report)", EditorStyles.miniLabel);
            }
        }
    }
}
