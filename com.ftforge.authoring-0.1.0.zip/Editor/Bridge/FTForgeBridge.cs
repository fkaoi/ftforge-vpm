using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace FTForge.Bridge
{
    /// <summary>
    /// Marks a static method <c>string Method(string argsJson)</c> as callable from the file bridge.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class BridgeCommandAttribute : Attribute
    {
        public readonly string Name;
        public BridgeCommandAttribute(string name) { Name = name; }
    }

    /// <summary>
    /// Lets external tools drive the open editor without batchmode.
    /// Request:  Library/FTForgeBridge/in/&lt;id&gt;.json   {"method": "...", "args": "..."}
    /// Response: Library/FTForgeBridge/out/&lt;id&gt;.json  {"ok": true, "result": "...", "error": ""}
    /// Console and compiler messages are appended to Library/FTForgeBridge/log.txt.
    /// </summary>
    [InitializeOnLoad]
    public static class FTForgeBridge
    {
        [Serializable] class Request { public string method; public string args; }
        [Serializable] class Response { public bool ok; public string result; public string error; }

        static readonly string Root = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "Library", "FTForgeBridge"));
        static readonly string InDir = Path.Combine(Root, "in");
        static readonly string OutDir = Path.Combine(Root, "out");
        static readonly string LogPath = Path.Combine(Root, "log.txt");
        static readonly string HeartbeatPath = Path.Combine(Root, "heartbeat.txt");

        static Dictionary<string, MethodInfo> _commands;
        static double _nextPoll, _nextBeat;
        static bool _busy;

        static FTForgeBridge()
        {
            Directory.CreateDirectory(InDir);
            Directory.CreateDirectory(OutDir);
            EditorApplication.update += Poll;
            Application.logMessageReceivedThreaded += OnLog;
            CompilationPipeline.assemblyCompilationFinished += OnCompiled;
            AppendLog($"[bridge] loaded {DateTime.Now:O}");
        }

        static void OnLog(string message, string stack, LogType type)
        {
            if (type == LogType.Log && !message.StartsWith("[FTForge]")) return;
            AppendLog($"[{type}] {message}" + (type == LogType.Exception || type == LogType.Error ? "\n" + stack : ""));
        }

        static void OnCompiled(string assembly, CompilerMessage[] messages)
        {
            foreach (var m in messages)
                AppendLog($"[compile:{m.type}] {m.file}({m.line}): {m.message}");
        }

        static void AppendLog(string line)
        {
            try { lock (Root) File.AppendAllText(LogPath, line + "\n"); } catch { /* ignore */ }
        }

        static void Poll()
        {
            double now = EditorApplication.timeSinceStartup;
            if (now >= _nextBeat)
            {
                _nextBeat = now + 2;
                try { File.WriteAllText(HeartbeatPath, $"{DateTime.Now:O} compiling={EditorApplication.isCompiling}"); } catch { }
            }
            if (_busy || now < _nextPoll || EditorApplication.isCompiling || EditorApplication.isUpdating) return;
            _nextPoll = now + 0.25;

            string[] files;
            try { files = Directory.GetFiles(InDir, "*.json"); } catch { return; }
            if (files.Length == 0) return;
            Array.Sort(files, StringComparer.Ordinal);

            string file = files[0];
            string id = Path.GetFileNameWithoutExtension(file);
            string text;
            try { text = File.ReadAllText(file); File.Delete(file); }
            catch { return; } // still being written

            _busy = true;
            var response = new Response();
            try
            {
                var req = JsonUtility.FromJson<Request>(text);
                response.result = Dispatch(req.method, req.args ?? "");
                response.ok = true;
            }
            catch (Exception e)
            {
                var inner = e is TargetInvocationException t && t.InnerException != null ? t.InnerException : e;
                response.ok = false;
                response.error = inner.ToString();
            }
            finally
            {
                _busy = false;
            }
            string tmp = Path.Combine(OutDir, id + ".tmp");
            File.WriteAllText(tmp, JsonUtility.ToJson(response));
            string dst = Path.Combine(OutDir, id + ".json");
            if (File.Exists(dst)) File.Delete(dst);
            File.Move(tmp, dst);
        }

        static string Dispatch(string method, string args)
        {
            if (_commands == null)
            {
                _commands = new Dictionary<string, MethodInfo>();
                foreach (var m in TypeCache.GetMethodsWithAttribute<BridgeCommandAttribute>())
                    _commands[m.GetCustomAttribute<BridgeCommandAttribute>().Name] = m;
            }
            if (!_commands.TryGetValue(method, out var mi))
                throw new ArgumentException($"Unknown command '{method}'. Known: {string.Join(", ", _commands.Keys.OrderBy(k => k))}");
            return (string)mi.Invoke(null, new object[] { args });
        }

        // ---- built-in commands ----

        [BridgeCommand("ping")]
        static string Ping(string _) => $"pong {Application.unityVersion} {DateTime.Now:O}";

        /// <summary>Re-imports changed files; scripts recompile afterwards and the domain reloads.</summary>
        [BridgeCommand("refresh")]
        static string Refresh(string _)
        {
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            CompilationPipeline.RequestScriptCompilation();
            return "refresh requested";
        }

        [BridgeCommand("compileErrors")]
        static string CompileErrors(string _)
        {
            // EditorUtility.scriptCompilationFailed reflects the last compilation.
            return EditorUtility.scriptCompilationFailed ? "failed" : "ok";
        }
    }
}
