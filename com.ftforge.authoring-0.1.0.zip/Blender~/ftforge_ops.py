"""FTForge Blender worker.

Run:  blender -b --factory-startup -P ftforge_ops.py -- <job_dir>

<job_dir>/job.json describes the work. Geometry arrives as raw little-endian arrays in Unity's
own vertex order (no FBX), so every delta written back maps 1:1 onto the Unity mesh.

job.json:
  vertexCount, triangleCount
  inputs:  {"positions": "positions.f32", "triangles": "triangles.i32", "side": "side.f32",
            "shapes": {"<name>": "<file>.f32", ...}}       # mesh-space position deltas
  ops:     [{"op": "split", "source": "<shape>", "side": "Left|Right", "falloff": 0.01, "output": "<name>"},
            {"op": "copy", "source": "<shape>", "output": "<name>"},
            {"op": "push", "seeds": "<file>.f32", "disp": "<file>.f32", "radius": r, "smooth": n, "output": "<name>"}]
  push (stage D): every seed vertex (weight > 0) gets its displacement; other vertices take the displacement
  of the nearest seed, faded by surface (geodesic) distance with a smoothstep over `radius` (mesh units).
  Distances follow the welded graph in inputs.graph (seam duplicates joined, holes such as the mouth slit
  are not crossed). The field is then Laplacian-smoothed `smooth` times with seeds held.
Writes <job_dir>/out_<output>.f32 (vertexCount*3 float32) and result.json.
"""
import json
import os
import sys
import traceback

import heapq

import bpy
import numpy as np


def load(job_dir, name, dtype, cols):
    a = np.fromfile(os.path.join(job_dir, name), dtype=dtype)
    return a.reshape(-1, cols) if cols > 1 else a


def build_mesh(positions, triangles):
    mesh = bpy.data.meshes.new("ftforge")
    n_v, n_t = len(positions), len(triangles)
    mesh.vertices.add(n_v)
    mesh.vertices.foreach_set("co", positions.astype(np.float32).ravel())
    mesh.loops.add(n_t * 3)
    mesh.loops.foreach_set("vertex_index", triangles.astype(np.int32).ravel())
    mesh.polygons.add(n_t)
    mesh.polygons.foreach_set("loop_start", np.arange(0, n_t * 3, 3, dtype=np.int32))
    mesh.polygons.foreach_set("loop_total", np.full(n_t, 3, dtype=np.int32))
    mesh.update(calc_edges=True)
    mesh.validate(clean_customdata=False)
    obj = bpy.data.objects.new("ftforge", mesh)
    bpy.context.scene.collection.objects.link(obj)
    obj.shape_key_add(name="Basis", from_mix=False)
    return obj


def add_shape(obj, name, delta):
    key = obj.shape_key_add(name=name, from_mix=False)
    basis = read_coords(obj.data.shape_keys.key_blocks["Basis"])
    key.data.foreach_set("co", (basis + delta).astype(np.float32).ravel())
    return key


def read_coords(key_block):
    co = np.empty(len(key_block.data) * 3, dtype=np.float32)
    key_block.data.foreach_get("co", co)
    return co.reshape(-1, 3)


def side_weights(side_coord, side, falloff):
    """1 on the requested side, 0 on the other, smoothstep across a band of width `falloff` at the centre.
    side_coord > 0 is the avatar's right. Left+Right weights sum to exactly 1."""
    half = max(falloff, 1e-6) * 0.5
    t = np.clip((side_coord + half) / (2 * half), 0.0, 1.0)
    right = t * t * (3 - 2 * t)
    return right if side == "Right" else 1.0 - right


def spatial_smooth(positions, field, radius, iterations=2):
    """Averages the field over all vertices within `radius` in 3D, ignoring connectivity, so separate pieces that
    touch (skin around an opening and the part filling it, seams) move together instead of tearing apart."""
    from mathutils import kdtree
    n = len(positions)
    kd = kdtree.KDTree(n)
    for i in range(n):
        kd.insert(positions[i].tolist(), i)
    kd.balance()
    neigh = [[j for (_, j, _) in kd.find_range(positions[i].tolist(), radius)] for i in range(n)]
    moving = np.nonzero(np.linalg.norm(field, axis=1) > 0)[0]
    active = set()
    for i in moving:
        active.update(neigh[i])
    active = np.array(sorted(active), dtype=np.int64)
    for _ in range(iterations):
        new = field.copy()
        for i in active:
            new[i] = field[neigh[i]].mean(axis=0)
        field = new
    return field


def follow_skin(field, weld, visible, proj):
    """Hidden vertices take the displacement of the visible skin in front of them (nearest visible vertex in the
    front projection), so inner parts can never be pushed through the skin."""
    from mathutils import kdtree
    vis_ids = np.nonzero(visible > 0)[0]
    if len(vis_ids) == 0:
        return field
    kd = kdtree.KDTree(len(vis_ids))
    for k, i in enumerate(vis_ids):
        kd.insert((float(proj[i, 0]), float(proj[i, 1]), 0.0), k)
    kd.balance()
    out = field.copy()
    for i in np.nonzero(visible <= 0)[0]:
        co, k, d = kd.find((float(proj[i, 0]), float(proj[i, 1]), 0.0))
        out[i] = field[vis_ids[k]]
    return out


def geodesic_push(positions, weld, edges, seeds, disp, radius, smooth, metric="geodesic"):
    """Nearest-seed falloff, then smoothing. Returns per-vertex mesh-space delta.
    metric "geodesic": distance along the welded surface (does not cross holes such as an open mouth slit).
    metric "euclid": straight-line distance, so hidden parts right behind the skin (inner mouth) move with it."""
    n_w = int(weld.max()) + 1
    wpos = np.zeros((n_w, 3)); np.add.at(wpos, weld, positions); cnt = np.bincount(weld, minlength=n_w)[:, None]
    wpos /= np.maximum(cnt, 1)
    wseed = np.zeros(n_w); np.maximum.at(wseed, weld, seeds)
    wdisp = np.zeros((n_w, 3)); np.add.at(wdisp, weld, disp); wdisp /= np.maximum(cnt, 1)
    adj = [[] for _ in range(n_w)]
    for a, b in edges:
        l = float(np.linalg.norm(wpos[a] - wpos[b]))
        adj[a].append((b, l)); adj[b].append((a, l))

    dist = np.full(n_w, np.inf); src = np.full(n_w, -1)
    if metric == "euclid":
        from mathutils import kdtree
        seed_ids = np.nonzero(wseed > 0)[0]
        kd = kdtree.KDTree(len(seed_ids))
        for k, i in enumerate(seed_ids):
            kd.insert(wpos[i].tolist(), k)
        kd.balance()
        for i in range(n_w):
            co, k, d = kd.find(wpos[i].tolist())
            if d <= radius:
                dist[i] = d; src[i] = seed_ids[k]
    heap = [] if metric == "euclid" else None
    if heap is None:
        heap = []
    if metric != "euclid":
        for i in np.nonzero(wseed > 0)[0]:
            dist[i] = 0.0; src[i] = i; heapq.heappush(heap, (0.0, int(i)))
    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u] or d > radius:
            continue
        for v, l in adj[u]:
            nd = d + l
            if nd < dist[v]:
                dist[v] = nd; src[v] = src[u]; heapq.heappush(heap, (nd, v))

    field = np.zeros((n_w, 3))
    reached = src >= 0
    t = np.clip(dist[reached] / max(radius, 1e-9), 0, 1)
    fade = 1 - t * t * (3 - 2 * t)
    field[reached] = wdisp[src[reached]] * fade[:, None]
    seed_mask = wseed > 0
    field[seed_mask] = wdisp[seed_mask]

    for _ in range(int(smooth)):
        avg = np.zeros_like(field); deg = np.zeros(n_w)
        for a, b in edges:
            avg[a] += field[b]; avg[b] += field[a]; deg[a] += 1; deg[b] += 1
        new = np.where(deg[:, None] > 0, avg / np.maximum(deg, 1)[:, None], field)
        field = np.where(seed_mask[:, None], field, 0.5 * field + 0.5 * new)
    return field[weld]


def main():
    job_dir = sys.argv[sys.argv.index("--") + 1]
    job = json.load(open(os.path.join(job_dir, "job.json"), encoding="utf-8"))
    result = {"ok": False, "outputs": {}, "blender": bpy.app.version_string}
    try:
        bpy.ops.wm.read_factory_settings(use_empty=True)
        inp = job["inputs"]
        positions = load(job_dir, inp["positions"], np.float32, 3)
        triangles = load(job_dir, inp["triangles"], np.int32, 3)
        side_coord = load(job_dir, inp["side"], np.float32, 1)
        assert len(positions) == job["vertexCount"], "vertex count mismatch"
        assert len(triangles) == job["triangleCount"], "triangle count mismatch"

        obj = build_mesh(positions, triangles)
        if len(obj.data.vertices) != job["vertexCount"]:
            raise RuntimeError(f"Blender changed the vertex count: {len(obj.data.vertices)}")
        for name, file in inp.get("shapes", {}).items():
            add_shape(obj, name, load(job_dir, file, np.float32, 3))

        blocks = obj.data.shape_keys.key_blocks
        basis = read_coords(blocks["Basis"])
        weld = edges = None
        if "graph" in inp:
            weld = load(job_dir, inp["graph"]["weld"], np.int32, 1)
            edges = load(job_dir, inp["graph"]["edges"], np.int32, 2)
        for op in job["ops"]:
            if op["op"] == "push":
                if weld is None:
                    raise ValueError("push needs inputs.graph")
                seeds = load(job_dir, op["seeds"], np.float32, 1)
                disp = load(job_dir, op["disp"], np.float32, 3)
                delta = geodesic_push(positions, weld, edges, seeds, disp, float(op["radius"]), op.get("smooth", 3), op.get("metric") or "geodesic")
                if op.get("spatial", 0) > 0:
                    delta = spatial_smooth(positions, delta, float(op["spatial"]))
                if op.get("visible"):
                    delta = follow_skin(delta, weld, load(job_dir, op["visible"], np.float32, 1), load(job_dir, op["proj"], np.float32, 2))
                add_shape(obj, op["output"], delta)
                out_file = f"out_{op['output']}.f32"
                (read_coords(blocks[op["output"]]) - basis).astype("<f4").tofile(os.path.join(job_dir, out_file))
                result["outputs"][op["output"]] = out_file
                continue
            src = read_coords(blocks[op["source"]]) - basis
            if op["op"] == "split":
                w = side_weights(side_coord, op["side"], float(op.get("falloff", 0.01)))
                delta = src * w[:, None]
            elif op["op"] == "copy":
                delta = src
            else:
                raise ValueError(f"unknown op {op['op']}")
            # Keep the result as a real shape key so later ops (and debugging .blend saves) can use it.
            add_shape(obj, op["output"], delta)
            out = read_coords(blocks[op["output"]]) - basis
            out_file = f"out_{op['output']}.f32"
            out.astype("<f4").tofile(os.path.join(job_dir, out_file))
            result["outputs"][op["output"]] = out_file

        if job.get("saveBlend"):
            bpy.ops.wm.save_as_mainfile(filepath=os.path.join(job_dir, "debug.blend"))
        result["ok"] = True
    except Exception:
        result["error"] = traceback.format_exc()
    json.dump(result, open(os.path.join(job_dir, "result.json"), "w", encoding="utf-8"), indent=1)


main()
