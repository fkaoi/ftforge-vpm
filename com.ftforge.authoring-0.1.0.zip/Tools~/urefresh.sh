#!/usr/bin/env bash
# Refreshes the open Unity editor, waits for the domain reload, prints new compile errors.
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)/Library/FTForgeBridge"
LOG="$ROOT/log.txt"
START=$(wc -l < "$LOG")
"$(dirname "$0")/ucall.sh" refresh "" 60 > /dev/null || exit 2
for ((i=0; i<240; i++)); do
  NEW=$(tail -n +"$((START+1))" "$LOG")
  if grep -q "\[compile:Error\]" <<< "$NEW"; then grep "\[compile:Error\]" <<< "$NEW" | sort -u; echo "COMPILE FAILED"; exit 1; fi
  if grep -q "\[bridge\] loaded" <<< "$NEW"; then echo "RELOADED OK"; grep "\[compile:Warning\].*ftforge" <<< "$NEW" | sort -u | head -20; exit 0; fi
  sleep 0.5
done
echo "No reload within 120s (maybe nothing changed)"; exit 0
