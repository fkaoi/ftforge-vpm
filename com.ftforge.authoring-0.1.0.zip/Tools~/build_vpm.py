"""Builds VPM release zips and the repository listing for FTForge.

Usage:
  python build_vpm.py <base-url> [out-dir]

  <base-url>  where the files will be hosted, e.g. https://example.github.io/ftforge
              (listing = <base-url>/vpm.json, zips = <base-url>/<name>-<version>.zip)
  out-dir     default: <project>/Library/FTForge/vpm

Writes <name>-<version>.zip for com.ftforge.core and com.ftforge.authoring, plus vpm.json.
Upload the whole out-dir to <base-url>; users add <base-url>/vpm.json in the VRChat Creator Companion.
Re-running with an existing vpm.json in out-dir keeps older versions in the listing.
"""
import hashlib
import json
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
PACKAGES = os.path.abspath(os.path.join(HERE, "..", ".."))
PROJECT = os.path.dirname(PACKAGES)
NAMES = ["com.ftforge.core", "com.ftforge.authoring"]
SKIP_DIRS = {".git", "Library", "__pycache__"}
SKIP_FILES = {".gitignore", ".gitattributes"}


def build_zip(pkg_dir, out_path):
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(pkg_dir):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
            for f in sorted(files):
                if f in SKIP_FILES or f.endswith(".tmp"):
                    continue
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, pkg_dir).replace(os.sep, "/"))
    with open(out_path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    base = sys.argv[1].rstrip("/")
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(PROJECT, "Library", "FTForge", "vpm")
    os.makedirs(out, exist_ok=True)

    listing_path = os.path.join(out, "vpm.json")
    listing = json.load(open(listing_path, encoding="utf-8")) if os.path.exists(listing_path) else {}
    listing.update({
        "name": "FTForge",
        "id": "com.ftforge.vpm",
        "url": f"{base}/vpm.json",
        "author": "FTForge",
    })
    listing.setdefault("packages", {})

    for name in NAMES:
        pkg_dir = os.path.join(PACKAGES, name)
        manifest = json.load(open(os.path.join(pkg_dir, "package.json"), encoding="utf-8"))
        version = manifest["version"]
        zip_name = f"{name}-{version}.zip"
        sha = build_zip(pkg_dir, os.path.join(out, zip_name))
        entry = dict(manifest)
        entry["url"] = f"{base}/{zip_name}"
        entry["zipSHA256"] = sha
        listing["packages"].setdefault(name, {"versions": {}})["versions"][version] = entry
        print(f"{zip_name}  sha256={sha[:16]}…  ({os.path.getsize(os.path.join(out, zip_name)) // 1024} KB)")

    with open(listing_path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(listing, fh, ensure_ascii=False, indent=2)
    print(f"listing: {listing_path}")


main()
