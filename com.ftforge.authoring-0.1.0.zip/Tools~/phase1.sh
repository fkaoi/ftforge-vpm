#!/usr/bin/env bash
# One command for Phase 1: analyse -> generate (Blender) -> apply -> FT settings -> capture -> evaluate -> report.
# Usage: phase1.sh [prefab path]   (runs in the open Unity editor through the FTForge bridge)
DIR="$(dirname "$0")"
"$DIR/ucall.sh" run "${1:-Assets/Amatousagi/Chocolat/Chocolat.prefab}" 900 \
  | python -c "import json,sys; d=json.load(sys.stdin); print(d['result'] if d['ok'] else 'ERROR\n'+d['error']); sys.exit(0 if d['ok'] else 1)"
