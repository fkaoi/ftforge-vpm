#!/usr/bin/env bash
# Usage: ucall.sh <method> [args-string] [timeout-seconds]
# Sends a command to the FTForge bridge in the open Unity editor and prints the result.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)/Library/FTForgeBridge"
METHOD="$1"; ARGS="${2:-}"; TIMEOUT="${3:-120}"
mkdir -p "$ROOT/in" "$ROOT/out"
ID="$(date +%s%N)"
python -c 'import json,sys; print(json.dumps({"method":sys.argv[1],"args":sys.argv[2]}))' "$METHOD" "$ARGS" > "$ROOT/in/$ID.tmp"
mv "$ROOT/in/$ID.tmp" "$ROOT/in/$ID.json"
for ((i=0; i<TIMEOUT*4; i++)); do
  if [[ -f "$ROOT/out/$ID.json" ]]; then cat "$ROOT/out/$ID.json"; echo; rm -f "$ROOT/out/$ID.json"; exit 0; fi
  sleep 0.25
done
rm -f "$ROOT/in/$ID.json"
echo "TIMEOUT after ${TIMEOUT}s (heartbeat: $(cat "$ROOT/heartbeat.txt" 2>/dev/null || echo none))" >&2
exit 2
