using System;
using System.Collections.Generic;
using UnityEngine;

namespace FTForge
{
    /// <summary>
    /// Per-avatar settings and results. Automatic results are refreshed on every run;
    /// anything under "override" is written by a person and is never changed by the tool.
    /// </summary>
    [CreateAssetMenu(menuName = "FTForge/Profile", fileName = "FTForgeProfile")]
    public sealed class FTForgeProfile : ScriptableObject
    {
        public enum OverrideMode
        {
            Auto,       // let the tool decide
            Disable,    // leave the key unassigned
            UseShape,   // map an existing blendshape by name
            UseRecipe,  // generate with a recipe expression
        }

        [Serializable]
        public sealed class KeyEntry
        {
            public string key;

            [Header("Override (manual)")]
            public OverrideMode mode = OverrideMode.Auto;
            [Tooltip("Blendshape name (UseShape) or recipe expression (UseRecipe).")]
            public string value = "";
            [Range(0f, 10f)] public float multiplier = 1f;
            [Tooltip("Split falloff in metres for this key; 0 = profile default.")]
            public float splitFalloff;
            public bool approved;
            [TextArea] public string memo = "";

            [Header("Last result (automatic)")]
            public string status = "";
            public string shape = "";
            public string recipe = "";
            public int score;
            public string issues = "";
            public int candidatesTried;
        }

        [Tooltip("Avatar prefab this profile was made for.")]
        public GameObject avatarPrefab;
        [Tooltip("Path of the face mesh relative to the avatar root; empty = detect.")]
        public string faceMeshPath = "";

        [Header("Generation defaults")]
        [Tooltip("Width of the centre band for left/right splits, metres.")]
        public float splitFalloff = 0.01f;
        [Tooltip("Region mask falloff, in inter-ocular distances.")]
        public float maskFalloff = 0.08f;
        [Tooltip("Splits are also tried at these multiples of the falloff; the best score wins.")]
        public float[] falloffCandidates = { 0.5f, 1f, 2f };

        [Header("Extra rules for this avatar (same syntax as Data/aliases.txt and Data/synth_rules.txt)")]
        [TextArea(3, 20)] public string extraAliases = "";
        [TextArea(3, 20)] public string extraRecipes = "";

        public List<KeyEntry> keys = new List<KeyEntry>();

        [Header("Last run")]
        public string lastRun = "";
        public string lastSummary = "";

        public KeyEntry Get(string key)
        {
            foreach (var k in keys) if (k.key == key) return k;
            return null;
        }

        public KeyEntry GetOrAdd(string key)
        {
            var e = Get(key);
            if (e != null) return e;
            e = new KeyEntry { key = key };
            keys.Add(e);
            return e;
        }
    }
}
