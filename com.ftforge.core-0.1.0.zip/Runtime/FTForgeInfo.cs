namespace FTForge
{
    public static class FTForgeInfo
    {
        public const string Version = "0.1.0";
    }
}
