using System;
using System.Collections.Generic;
using UnityEngine;

namespace FTForge
{
    /// <summary>
    /// Distributable result: generated blendshapes as sparse per-vertex deltas (no original mesh data) plus the
    /// face tracking mappings. Applied at build time by the FTForge NDMF pass.
    /// </summary>
    [CreateAssetMenu(menuName = "FTForge/Shape Data", fileName = "FTForgeShapeData")]
    public sealed class FTForgeShapeData : ScriptableObject
    {
        [Serializable]
        public sealed class Shape
        {
            public string name;
            public int[] indices;          // vertices that move
            public Vector3[] positions;    // mesh-space position delta per listed vertex
            public Vector3[] normals;      // mesh-space normal delta per listed vertex
        }

        [Serializable]
        public sealed class MeshDeltas
        {
            [Tooltip("Renderer path relative to the avatar root.")]
            public string rendererPath;
            [Tooltip("Name of the mesh the deltas were made for.")]
            public string meshName;
            public int vertexCount;
            [Tooltip("Hash of the base vertex positions; the deltas are only applied to the identical mesh.")]
            public string baseHash;
            public List<Shape> shapes = new List<Shape>();
        }

        [Serializable]
        public sealed class Mapping
        {
            public string key;             // Unified Expressions key name
            public string rendererPath;
            public string shape;
            public float multiplier = 1f;
        }

        public string sourceAvatar;
        public string generatorVersion;
        public bool useAllTrackingKeys = true;
        public List<MeshDeltas> meshes = new List<MeshDeltas>();
        public List<Mapping> mappings = new List<Mapping>();
    }
}
