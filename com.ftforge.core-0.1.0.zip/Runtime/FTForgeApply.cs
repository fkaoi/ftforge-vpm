using UnityEngine;

namespace FTForge
{
    /// <summary>
    /// Put anywhere under an avatar. At build time FTForge adds the generated blendshapes to copies of the meshes
    /// and configures native face tracking. Nothing is changed in the scene or in the source assets.
    /// </summary>
    [AddComponentMenu("FTForge/FTForge Apply")]
    [DisallowMultipleComponent]
    public sealed class FTForgeApply : MonoBehaviour, VRC.SDKBase.IEditorOnly
    {
        public FTForgeShapeData data;
        [Tooltip("Write the face tracking section of the avatar descriptor (meshes, mappings, lip sync / eye modes).")]
        public bool configureDescriptor = true;
    }
}
