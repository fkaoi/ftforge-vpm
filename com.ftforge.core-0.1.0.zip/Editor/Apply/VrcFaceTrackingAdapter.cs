using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3A.Editor;
using VRC.SDKBase.Validation.Performance;
using VRC.SDKBase.Validation.Performance.Stats;
using VRC.SDKBase;

namespace FTForge.Adapters
{
    /// <summary>
    /// The only place that touches VRChat SDK Face Tracking types and fields.
    /// Verified against Avatars SDK 3.10.6. When the SDK changes, fix this file only.
    /// </summary>
    public static class VrcFaceTrackingAdapter
    {
        public const int MaxMeshes = 16;
        public const string SetName = "FTForge";

        static string[] _keyNames;

        /// <summary>Unified Expressions key names in SDK index order.</summary>
        public static IReadOnlyList<string> KeyNames => _keyNames ??= Enumerable
            .Range(0, (int)VRCAvatarDescriptor.FaceTrackingKey.Max)
            .Select(i => ((VRCAvatarDescriptor.FaceTrackingKey)i).ToString())
            .ToArray();

        public static IReadOnlyList<string> VisemeNames => Enumerable
            .Range(0, (int)VRC_AvatarDescriptor.Viseme.Count)
            .Select(i => ((VRC_AvatarDescriptor.Viseme)i).ToString())
            .ToArray();

        /// <summary>The names the SDK Auto-Fill would accept for a key (reference data only).</summary>
        public static IEnumerable<string> SdkAliases(string key)
        {
            if (!Enum.TryParse(key, out VRCAvatarDescriptor.FaceTrackingKey k)) return Array.Empty<string>();
            return FaceTrackingAutoFillAccess.Names(k);
        }

        public sealed class Config
        {
            public List<SkinnedMeshRenderer> meshes = new List<SkinnedMeshRenderer>();
            /// <summary>key name -> (blendshape name, multiplier)</summary>
            public Dictionary<string, (string name, float multiplier)> mappings = new Dictionary<string, (string, float)>();
            public string[] visemes; // by VRC viseme index; null = copy from legacy viseme slots
            public bool useAllTrackingKeys = true;
        }

        public sealed class State
        {
            public bool enabled, useAllKeys;
            public string lipSync, eyeGazeMode, eyelidType;
            public List<string> meshes = new List<string>();
            public List<string> setNames = new List<string>();
            public int mappedKeys;
        }

        public static State Read(VRCAvatarDescriptor d)
        {
            var s = new State
            {
                enabled = d.enableFaceTracking,
                useAllKeys = d.useAllTrackingKeys,
                lipSync = d.lipSync.ToString(),
                eyeGazeMode = d.customEyeLookSettings.eyeGazeMode.ToString(),
                eyelidType = d.customEyeLookSettings.eyelidType.ToString(),
            };
            if (d.faceTrackingMeshes != null)
                s.meshes.AddRange(d.faceTrackingMeshes.Where(m => m != null).Select(m => m.name));
            if (d.faceTrackingBlendshapesSetList != null)
                foreach (var set in d.faceTrackingBlendshapesSetList)
                {
                    s.setNames.Add(set.setName);
                    s.mappedKeys += set.faceTrackingBlendshapeNames?.Count(n => !string.IsNullOrEmpty(n)) ?? 0;
                }
            return s;
        }

        /// <summary>
        /// Writes the face tracking section. Replaces only the FTForge set and keeps other sets.
        /// </summary>
        public static void Write(VRCAvatarDescriptor d, Config c)
        {
            if (c.meshes.Count > MaxMeshes) throw new ArgumentException($"Face tracking supports at most {MaxMeshes} meshes.");
            Undo.RecordObject(d, "FTForge: configure face tracking");

            // Legacy viseme slots must be read before lipSync changes.
            string[] legacyVisemes = c.visemes ?? ReadLegacyVisemes(d);

            d.enableFaceTracking = true;
            d.useAllTrackingKeys = c.useAllTrackingKeys;
            d.faceTrackingMeshes = new List<SkinnedMeshRenderer>(c.meshes.Distinct());

            int keyCount = (int)VRCAvatarDescriptor.FaceTrackingKey.Max;
            int visemeCount = (int)VRC_AvatarDescriptor.Viseme.Count;
            var set = new VRCAvatarDescriptor.FaceTrackingBlendshapesSet
            {
                setName = SetName,
                setWeight = 1f,
                faceTrackingBlendshapeNames = new string[keyCount],
                faceTrackingBlendshapeMultipliers = new float[keyCount],
                visemeBlendshapeNames = new string[visemeCount],
                visemeBlendshapeMultipliers = new float[visemeCount],
            };
            for (int i = 0; i < keyCount; i++)
            {
                set.faceTrackingBlendshapeNames[i] = "";
                set.faceTrackingBlendshapeMultipliers[i] = 1f;
                if (c.mappings.TryGetValue(KeyNames[i], out var m))
                {
                    set.faceTrackingBlendshapeNames[i] = m.name ?? "";
                    set.faceTrackingBlendshapeMultipliers[i] = Mathf.Clamp(m.multiplier, 0f, 10f);
                }
            }
            for (int i = 0; i < visemeCount; i++)
            {
                set.visemeBlendshapeNames[i] = legacyVisemes != null && i < legacyVisemes.Length ? legacyVisemes[i] ?? "" : "";
                set.visemeBlendshapeMultipliers[i] = 1f;
            }

            var sets = d.faceTrackingBlendshapesSetList ?? new List<VRCAvatarDescriptor.FaceTrackingBlendshapesSet>();
            int existing = sets.FindIndex(x => x != null && x.setName == SetName);
            if (existing >= 0) sets[existing] = set; else sets.Insert(0, set);
            d.faceTrackingBlendshapesSetList = sets;

            d.lipSync = VRC_AvatarDescriptor.LipSyncStyle.VisemeBlendShapeFaceTracking;
            d.enableEyeLook = true;
            var eye = d.customEyeLookSettings;
            if (eye.eyeGazeMode == VRCAvatarDescriptor.CustomEyeLookSettings.EyeGazeMode.BoneRotation)
                eye.eyeGazeMode = VRCAvatarDescriptor.CustomEyeLookSettings.EyeGazeMode.Both;
            // EyeClosed mappings are ignored unless the eyelid type is None or FaceTracking.
            eye.eyelidType = VRCAvatarDescriptor.EyelidType.FaceTracking;
            d.customEyeLookSettings = eye;

            EditorUtility.SetDirty(d);
        }

        /// <summary>Viseme blendshape names in SDK viseme order, from whichever place the current lip sync mode uses.</summary>
        public static string[] ReadVisemes(VRCAvatarDescriptor d) => ReadLegacyVisemes(d) ?? Array.Empty<string>();

        static string[] ReadLegacyVisemes(VRCAvatarDescriptor d)
        {
            if (d.lipSync == VRC_AvatarDescriptor.LipSyncStyle.VisemeBlendShapeFaceTracking)
            {
                var own = d.faceTrackingBlendshapesSetList?.FirstOrDefault(x => x != null && x.setName == SetName);
                return own?.visemeBlendshapeNames;
            }
            return d.VisemeBlendShapes;
        }

        /// <summary>SDK validator: mapped names that are missing from every registered mesh.</summary>
        public static List<string> UnresolvedBlendshapes(VRCAvatarDescriptor d)
            => FaceTrackingMappingValidator.CollectIssues(d).UnresolvedBlendshapes.ToList();

        /// <summary>Face tracking performance stat as computed by the SDK, or null if unavailable.</summary>
        public static int? MeasureOperations(GameObject avatar)
        {
            var stats = new AvatarPerformanceStats(false);
            AvatarPerformance.CalculatePerformanceStats(avatar.name, avatar, stats, false);
            return stats.faceTrackingOperations;
        }
    }

    static class FaceTrackingAutoFillAccess
    {
        static System.Reflection.MethodInfo _method;

        public static IEnumerable<string> Names(VRCAvatarDescriptor.FaceTrackingKey key)
        {
            _method ??= typeof(FaceTrackingMappingValidator).Assembly
                .GetType("VRC.SDK3A.Editor.FaceTrackingAutoFill")
                ?.GetMethod("GetNamesForFaceTrackingKey", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);
            return _method?.Invoke(null, new object[] { key }) as IEnumerable<string> ?? Array.Empty<string>();
        }
    }
}
