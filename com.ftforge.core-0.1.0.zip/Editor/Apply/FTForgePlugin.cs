using FTForge;
using nadena.dev.ndmf;
using UnityEngine;

[assembly: ExportsPlugin(typeof(FTForge.Ndmf.FTForgePlugin))]

namespace FTForge.Ndmf
{
    /// <summary>
    /// Build-time application of FTForge data. Runs in Transforming before Modular Avatar (renderer paths are still
    /// those of the original avatar) and therefore before Avatar Optimizer, which sees the face tracking mappings and
    /// keeps the new blendshapes. VRCFury runs after NDMF and merges face tracking settings on its own.
    /// </summary>
    public sealed class FTForgePlugin : Plugin<FTForgePlugin>
    {
        public override string QualifiedName => "com.ftforge.core";
        public override string DisplayName => "FTForge";

        protected override void Configure()
        {
            InPhase(BuildPhase.Transforming)
                .BeforePlugin("nadena.dev.modular-avatar")
                .Run("Apply FTForge shapes and face tracking", ctx =>
                {
                    foreach (var apply in ctx.AvatarRootObject.GetComponentsInChildren<FTForgeApply>(true))
                    {
                        if (apply.data == null) { Debug.LogWarning("[FTForge] FTForge Apply without data", apply); }
                        else
                        {
                            var log = ShapeApply.Apply(ctx.AvatarRootTransform, apply.data, apply.configureDescriptor, o => ctx.AssetSaver.SaveAsset(o));
                            foreach (var line in log)
                            {
                                if (line.StartsWith("ERROR")) Debug.LogError("[FTForge] " + line, apply);
                                else if (line.StartsWith("WARN")) Debug.LogWarning("[FTForge] " + line, apply);
                                else Debug.Log("[FTForge] " + line);
                            }
                        }
                        Object.DestroyImmediate(apply);
                    }
                });
        }
    }
}
