using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using FTForge.Adapters;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace FTForge
{
    /// <summary>
    /// Applies <see cref="FTForgeShapeData"/> to an avatar: adds the generated blendshapes to mesh copies and writes
    /// the face tracking settings. Used by the NDMF pass at build time and by FTForge's own previews.
    /// </summary>
    public static class ShapeApply
    {
        /// <summary>Hash of the base vertex positions (exact bits), so deltas are only applied to the mesh they were made for.</summary>
        public static string BaseHash(Mesh mesh)
        {
            var v = mesh.vertices;
            var bytes = new byte[v.Length * 12];
            for (int i = 0; i < v.Length; i++)
            {
                Buffer.BlockCopy(BitConverter.GetBytes(v[i].x), 0, bytes, i * 12, 4);
                Buffer.BlockCopy(BitConverter.GetBytes(v[i].y), 0, bytes, i * 12 + 4, 4);
                Buffer.BlockCopy(BitConverter.GetBytes(v[i].z), 0, bytes, i * 12 + 8, 4);
            }
            using var sha = SHA256.Create();
            return BitConverter.ToString(sha.ComputeHash(bytes), 0, 12).Replace("-", "").ToLowerInvariant();
        }

        /// <summary>
        /// Adds the shapes to copies of the target meshes and (optionally) writes the face tracking settings.
        /// <paramref name="saveAsset"/> receives every new mesh (NDMF: the build's asset saver). Returns log lines;
        /// a mesh that does not match (count / hash) is skipped with an error line.
        /// </summary>
        public static List<string> Apply(Transform root, FTForgeShapeData data, bool configureDescriptor, Action<UnityEngine.Object> saveAsset = null)
        {
            var log = new List<string>();
            var renderers = new Dictionary<string, SkinnedMeshRenderer>();
            foreach (var md in data.meshes)
            {
                var t = root.Find(md.rendererPath);
                var r = t != null ? t.GetComponent<SkinnedMeshRenderer>() : null;
                if (r == null || r.sharedMesh == null) { log.Add($"ERROR: renderer '{md.rendererPath}' not found"); continue; }
                var src = r.sharedMesh;
                if (src.vertexCount != md.vertexCount) { log.Add($"ERROR: '{md.rendererPath}' has {src.vertexCount} vertices, data expects {md.vertexCount} (different avatar version?)"); continue; }
                string hash = BaseHash(src);
                if (hash != md.baseHash) { log.Add($"ERROR: '{md.rendererPath}' mesh differs from the one the data was made for (hash {hash} ≠ {md.baseHash})"); continue; }

                var mesh = UnityEngine.Object.Instantiate(src);
                mesh.name = src.name + "_FTForge";
                int added = 0;
                foreach (var shape in md.shapes)
                {
                    if (mesh.GetBlendShapeIndex(shape.name) >= 0) { log.Add($"WARN: '{shape.name}' already exists on {src.name}; kept the existing one"); continue; }
                    var dp = new Vector3[mesh.vertexCount];
                    var dn = new Vector3[mesh.vertexCount];
                    for (int i = 0; i < shape.indices.Length; i++) { dp[shape.indices[i]] = shape.positions[i]; dn[shape.indices[i]] = shape.normals[i]; }
                    mesh.AddBlendShapeFrame(shape.name, 100f, dp, dn, null);
                    added++;
                }
                saveAsset?.Invoke(mesh);
                r.sharedMesh = mesh;
                renderers[md.rendererPath] = r;
                log.Add($"{md.rendererPath}: +{added} blendshapes");
            }

            if (configureDescriptor)
            {
                var d = root.GetComponent<VRCAvatarDescriptor>();
                if (d == null) { log.Add("ERROR: no VRCAvatarDescriptor on the avatar root"); return log; }
                var config = new VrcFaceTrackingAdapter.Config { useAllTrackingKeys = data.useAllTrackingKeys };
                foreach (var m in data.mappings)
                {
                    if (!renderers.TryGetValue(m.rendererPath, out var r))
                    {
                        var t = root.Find(m.rendererPath);
                        r = t != null ? t.GetComponent<SkinnedMeshRenderer>() : null;
                        if (r == null) { log.Add($"WARN: mapping {m.key}: renderer '{m.rendererPath}' not found"); continue; }
                        renderers[m.rendererPath] = r;
                    }
                    if (r.sharedMesh.GetBlendShapeIndex(m.shape) < 0) { log.Add($"WARN: mapping {m.key}: '{m.shape}' not on {m.rendererPath}"); continue; }
                    config.mappings[m.key] = (m.shape, m.multiplier);
                    if (!config.meshes.Contains(r)) config.meshes.Add(r);
                }
                VrcFaceTrackingAdapter.Write(d, config);
                log.Add($"face tracking: {config.mappings.Count} keys on {config.meshes.Count} mesh(es)");
            }
            return log;
        }
    }
}
